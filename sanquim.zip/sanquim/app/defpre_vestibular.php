<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class defpre_vestibular extends Model {
    public $timestamps = false;
    protected $table = 'defpre-vestibular';
    protected $fillable = ['definicao'];
}