<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class imgRevista extends Model {
    public $timestamps = false;
    protected $table = 'imgRevista';
    protected $fillable = ['imagem'];
}