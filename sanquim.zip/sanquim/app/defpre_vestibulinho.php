<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class defpre_vestibulinho extends Model {
    public $timestamps = false;
    protected $table = 'defpre-vestibulinho';
    protected $fillable = ['definicao'];
}