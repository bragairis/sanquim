<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use App\professores;
use App\alunoscarrossel;
use App\msgpatrocinador;
use App\defhome;
use App\defsanquim;
use App\defpre_vestibular;
use App\defpre_vestibulinho;
use App\carrossel;
use App\footer;
use App\revista;
use App\imgRevista;
use App\horarios;
use App\user;
use App\sobre_revista;
use App\simulados_vestibular;
use App\simulados_vestibulinho;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\SanquimRequest;
use App\Http\Requests\FooterRequest;
use App\Http\Requests\DefinicoesRequest;
use App\Http\Requests\imgRevistaRequest;
use App\Http\Requests\RevistaRequest;
use App\Http\Requests\ProfessoresRequest;
use App\Http\Requests\HorarioRequest;
use App\Http\Requests\Sobre_revistaRequest;
use App\Http\Requests\AlunosCarrosselRequest;
use App\Http\Requests\SimuladosRequest;
use App\Http\Requests\CarrosselRequest;

class ConfiguracoesController extends Controller{
    
    public function edita($id=1) {
        $footer = footer::find($id=1);
        $title ="editar: {$footer-> localizacao}";
        $categorys =['localizacao','horario','telefone', 'facebook', 'instagram'] ;

        //defhome
        $defhome = defhome::find($id=1);
        $title ="editar : {$defhome-> definicao}";
        $categorys =['definicao'] ;

        //defsanquim
        $defsanquim = defsanquim::find($id=1);
        $title ="editar : {$defsanquim-> definicao}";
        $categorys =['definicao'] ;

        //defpre-vestibular
        $defpre_vestibular = defpre_vestibular::find($id=1);
        $title ="editar : {$defpre_vestibular-> definicao}";
        $categorys =['definicao'] ;

        //defpre-vestibulinho
        $defpre_vestibulinho = defpre_vestibulinho::find($id=1);
        $title ="editar : {$defpre_vestibulinho-> definicao}";
        $categorys =['definicao'] ;
        return view ('configuracoes', compact('title','categorys','defhome', 'footer', 'defsanquim', 'defpre_vestibular', 'defpre_vestibulinho'));

     }

    public function updatefooter (FooterRequest $request, $id=1) {
        $user = $request->all();
        $footer = footer::find($id=1);
        $footer->fill($user);
        $footer->save();
        return redirect('/configuracoes');
    }

    public function updatedefhome (DefinicoesRequest $request, $id=1) {
        $user = $request->all();
        $defhome = defhome::find($id=1);
        $defhome->fill($user);
        $defhome->save();
        return redirect('/configuracoes');
    }

    public function updatedefsanquim (DefinicoesRequest $request, $id=1) {
        $user = $request->all();
        $defsanquim = defsanquim::find($id=1);
        $defsanquim->fill($user);
        $defsanquim->save();
        return redirect('/configuracoes');
    }

    public function updatedefpre_vestibular (DefinicoesRequest $request, $id=1) {
        $user = $request->all();
        $defpre_vestibular = defpre_vestibular::find($id=1);
        $defpre_vestibular->fill($user);
        $defpre_vestibular->save();
        return redirect('/configuracoes');
    }

    public function updatedefpre_vestibulinho (DefinicoesRequest $request, $id=1) {
        $user = $request->all();
        $defpre_vestibulinho = defpre_vestibulinho::find($id=1);
        $defpre_vestibulinho->fill($user);
        $defpre_vestibulinho->save();
        return redirect('/configuracoes');
    }

    public function imgRevista(imgRevistaRequest $request){

        $nameFile=null;        
        if($request->hasFile('imagem') && $request->file('imagem')->isValid()) {        
        $name = uniqid(date('HisYmd'));    
        $extension = $request->imagem->extension();        
        $nameFile = "{$name}.{$extension}";        
        $upload = $request->imagem->storeAs('img/imgRevista', $nameFile);        
    
        if (!$upload) {        
        return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();        
        }                
        
        $user = $request->all();        
        $imgRevista = imgRevista::find($id=1);         
        $user['imagem'] = $nameFile;        
        $imgRevista->fill($user);        
        $imgRevista->save();        
        return redirect('/configuracoes');
        
        }
        
    }

    public function imagem_carrossel(Request $request){
        $user = $request->all();  
        
        $File1="";     
        $File2="";   
        $File3=""; 

        if($request->hasFile('foto1') && $request->file('foto1')->isValid()) {        
            $name = ('foto1');    
            $extension = $request->foto1->extension();        
            $File1 = "{$name}.{$extension}";        
            $upload = $request->foto1->storeAs('img/carrossel', $File1);        
        
            if (!$upload) {        
            return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();        
            } 

            $user['foto1'] = $File1;
        }
    
                
        if($request->hasFile('foto2') && $request->file('foto2')->isValid()) {        
            $name = ('foto2');    
            $extension = $request->foto2->extension();        
            $File2 = "{$name}.{$extension}";        
            $upload = $request->foto2->storeAs('img/carrossel', $File2);        
        
            if (!$upload) {        
            return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();        
            }
            $user['foto2'] = $File2;
        }

              
        if($request->hasFile('foto3') && $request->file('foto3')->isValid()) {        
            $name = ('foto3');    
            $extension = $request->foto3->extension();        
            $File3 = "{$name}.{$extension}";        
            $upload = $request->foto3->storeAs('img/carrossel', $File3);        
        
            if (!$upload) {        
            return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();        
            }
            $user['foto3'] = $File3;     
        }

        $carrossel = carrossel::find($id=1);         
        $carrossel->fill($user);        
        $carrossel->save();        
        return redirect('/configuracoes');
        
        
    }
    
   

    public function UpRevista(RevistaRequest $request)
    {
        $nameFile=null;
        if($request->hasFile('arquivo') && $request->file('arquivo')->isValid()) {
            $name = ('arquivo');
            $extension = $request->arquivo->extension();
            $nameFile = "{$name}.{$extension}";
            $upload = $request->arquivo->storeAs('pdf/revista', $nameFile);

            if (!$upload) {
                return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();
            }

            $sent = $request->all();
            $sent['arquivo'] = $nameFile;
            revista::create($sent);
            return redirect('/configuracoes');
        }
    }

    public function AddProfessores(ProfessoresRequest $request)
    {
      
        $nameFile=null;
        if($request->hasFile('foto') && $request->file('foto')->isValid()) {
            $name = uniqid(date('HisYmd'));
            $extension = $request->foto->extension();
            $nameFile = "{$name}.{$extension}";
            $upload = $request->foto->storeAs('img/professores', $nameFile);

            if (!$upload) {
                return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();
            }

            $sent = $request->all();
            $sent['foto'] = $nameFile;
            professores::create($sent);
            return redirect('/configuracoes');
        }
    }

    public function UpHorarios(HorarioRequest $request)
    {
        $nameFile=null;
        if($request->hasFile('arquivo') && $request->file('arquivo')->isValid()) {
            $name = uniqid(date('HisYmd'));
            $extension = $request->arquivo->extension();
            $nameFile = "{$name}.{$extension}";
            $upload = $request->arquivo->storeAs('pdf/horarios', $nameFile);

            if (!$upload) {
                return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();
            }

            $user = $request->all();        
            $horarios = horarios::find($id=1);         
            $user['arquivo'] = $nameFile;        
            $horarios->fill($user);        
            $horarios->save();        
            return redirect('/configuracoes');

        
        }
    }

    public function sobre_revista(Sobre_revistaRequest $request)
    {
        $nameFile=null;
        if($request->hasFile('foto') && $request->file('foto')->isValid()) {
            $name = uniqid(date('HisYmd'));
            $extension = $request->foto->extension();
            $nameFile = "{$name}.{$extension}";
            $upload = $request->foto->storeAs('img/sobre-revista', $nameFile);

            if (!$upload) {
                return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();
            }

            $user = $request->all();        
            $sobre_revista = sobre_revista::find($id=1);         
            $user['imagem'] = $nameFile;        
            $sobre_revista->fill($user);        
            $sobre_revista->save();        
            return redirect('/configuracoes');
        }
    }

    public function addalunos_carrossel(AlunosCarrosselRequest $request)
    {
        $nameFile=null;
        if($request->hasFile('foto') && $request->file('foto')->isValid()) {
            $name = uniqid(date('HisYmd'));
            $extension = $request->foto->extension();
            $nameFile = "{$name}.{$extension}";
            $upload = $request->foto->storeAs('img/alunos-carrossel', $nameFile);

            if (!$upload) {
                return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();
            }

            $sent = $request->all();
            $sent['foto'] = $nameFile;
            alunoscarrossel::create($sent);
            return redirect('/configuracoes');
        
        }
    }

    public function AddSimulados_vestibular(SimuladosRequest $request){
       
        $sent = $request->all();
        simulados_vestibular::create($sent);
        return redirect('/configuracoes');

    }

    public function AddSimulados_vestibulinho(SimuladosRequest $request){

        $sent = $request->all();
        simulados_vestibulinho::create($sent);
        return redirect('/configuracoes');

    }

    public function validacprofessor(){
        $user = User::where('id', '>', 0)->orderby('id', 'desc')->get();
        return view('validac-professor')->with('user', $user);
    } 
    
    public function validacvestibulinho(){
        $user = User::where('id', '>', 0)->orderby('id', 'desc')->get();
        return view('validac-vestibulinho')->with('user', $user);
    } 

    public function validacvestibular(){
        $user = User::where('id', '>', 0)->orderby('id', 'desc')->get();
       return view('validac-vestibular')->with('user', $user);
    }

     public function validacvestibulard(Request $request) {
        $id = $request->id;
        $user = user::find($id);
        $user->delete();
       return redirect()->action('ConfiguracoesController@validacvestibular');
    } 

    public function validacvestibulinhod(Request $request) {
        $id = $request->id;
        $user = user::find($id);
        $user->delete();
       return redirect()->action('ConfiguracoesController@validacvestibulinho');
    } 

    public function validacprofessord(Request $request) {
        $id = $request->id;
        $user = user::find($id);
        $user->delete();
       return redirect()->action('ConfiguracoesController@validacprofessor');
    } 

    public function deletarvestibular (Request $request){
        User::where('sala', $request->nomeSala)->delete();
        return redirect()->action('ConfiguracoesController@validacvestibular');
    }

    public function deletarvestibulinho (Request $request){
        User::where('sala', $request->nomeSala)->delete();
        return redirect()->action('ConfiguracoesController@validacvestibulinho');
    }

    
}