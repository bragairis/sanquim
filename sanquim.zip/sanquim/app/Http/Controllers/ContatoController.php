<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use App\professores;
use App\noticia;
use App\alunoscarrossel;
use App\msgpatrocinador;
use App\defhome;
use App\defsanquim;
use App\defpre_vestibular;
use App\defpre_vestibulinho;
use App\carrossel;
use App\footer;
use App\revista;
use App\user;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\SanquimRequest;
use App\Http\Requests\FooterRequest;
use App\Http\Requests\NoticiaRequest;

class ContatoController extends Controller{
    
    public function carrossel_contato() {
        $carrossel = carrossel::all();
        return view('contato')->with('carrossel',$carrossel);
    }

    public function mensagem(SanquimRequest $request)
    {
        $sent = $request->all();
        msgpatrocinador::create($sent);
        return redirect('contato');
    }

    public function mostramensagem() {
        $msgpatrocinador = msgpatrocinador::where('id', '>', 0)->orderby('id', 'desc')->get();
        return view('msg-adm')->with('msgpatrocinador',$msgpatrocinador);
    }
}