<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use App\professores;
use App\noticia;
use App\alunoscarrossel;
use App\msgpatrocinador;
use App\defhome;
use App\defsanquim;
use App\defpre_vestibular;
use App\defpre_vestibulinho;
use App\carrossel;
use App\footer;
use App\revista;
use App\user;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\SanquimRequest;
use App\Http\Requests\FooterRequest;
use App\Http\Requests\NoticiaRequest;

class NoticiaController extends Controller{
    public function criarnoticia(NoticiaRequest $request)
    {
        $nameFile=null;
        if($request->hasFile('imagem') && $request->file('imagem')->isValid()) {
            $name = uniqid(date('HisYmd'));
            $extension = $request->imagem->extension();
            $nameFile = "{$name}.{$extension}";
            $upload = $request->imagem->storeAs('img/noticia', $nameFile);

            if (!$upload) {
                return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();
            }

            $sent = $request->all();
            $sent['imagem'] = $nameFile;
            noticia::create($sent);
            return redirect('/criarnoticia');
        }
    }

    public function listaNoticia() {
        $carrossel = carrossel::all();
        $noticia = noticia::where('id', '>', 0)->orderby('id', 'desc')->get();
        return view('noticias')->with('noticia', $noticia)->with('carrossel',$carrossel);
    }

    public function mostraNoticia($id){
        $noticia = noticia:: find($id);
       return view('MostrarNoticia')->with('noticia', $noticia);
   }

   public function deletarNoticia(Request $request) {
    $id = $request->id;
    $noticia = noticia::find($id);
    $noticia->delete($id);
    return redirect()->action('Area_usuarioController@nivel');
}
}