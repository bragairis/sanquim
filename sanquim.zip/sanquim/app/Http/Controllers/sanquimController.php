<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use App\professores;
use App\noticia;
use App\alunoscarrossel;
use App\msgpatrocinador;
use App\defhome;
use App\defsanquim;
use App\defpre_vestibular;
use App\defpre_vestibulinho;
use App\carrossel;
use App\footer;
use App\revista;
use App\imgRevista;
use App\user;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\SanquimRequest;
use App\Http\Requests\FooterRequest;
use App\Http\Requests\NoticiaRequest;

class SanquimController extends Controller
{
    public function listaprof() {
        $carrossel = carrossel::all();
        $professores = professores::where('id', '>', 0)->orderby('id', 'desc')->get();
        return view('professores')->with('professores', $professores)->with('carrossel',$carrossel);
    }

    public function home() {
        $alunoscarrossel = alunoscarrossel::where('id', '>', 0)->orderby('id', 'desc')->limit('4')->get();
        $defhome = defhome::all();
        $carrossel = carrossel::all();
        $imgRevista = imgRevista::all();
        $noticia = noticia::where('id', '>', 0)->orderby('id', 'desc')->limit('4')->get();
        return view('index')
        ->with('alunoscarrossel', $alunoscarrossel)
        ->with('defhome',$defhome)
        ->with('imgRevista',$imgRevista)
        ->with('noticia',$noticia)
        ->with('carrossel',$carrossel);
    }
    

    public function defsanquim() {
        $defsanquim = defsanquim::all();
        $carrossel = carrossel::all();
        return view('defsanquim')->with('defsanquim',$defsanquim)->with('carrossel',$carrossel);
    }

    public function defpre_vestibular() {
        $defpre_vestibular = defpre_vestibular::all();
        $carrossel = carrossel::all();
        return view('prevestibular')->with('defpre_vestibular',$defpre_vestibular)->with('carrossel',$carrossel);
    }

    public function defpre_vestibulinho() {
        $carrossel = carrossel::all();
        $defpre_vestibulinho = defpre_vestibulinho::all();
        return view('prevestibulinho')->with('defpre_vestibulinho',$defpre_vestibulinho)->with('carrossel',$carrossel);
    }
    
    public function mostrafooter() {
        $footer = footer::all();
        return view('layout.principal');

    }
    
    





}

