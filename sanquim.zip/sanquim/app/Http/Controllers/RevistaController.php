<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use App\professores;
use App\noticia;
use App\alunoscarrossel;
use App\msgpatrocinador;
use App\defhome;
use App\defsanquim;
use App\defpre_vestibular;
use App\defpre_vestibulinho;
use App\carrossel;
use App\footer;
use App\revista;
use App\sobre_revista;
use App\user;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\SanquimRequest;
use App\Http\Requests\FooterRequest;
use App\Http\Requests\NoticiaRequest;
use App\Http\Requests\RevistaRequest;

class RevistaController extends Controller{

    public function MostraRevista() {
        $carrossel = carrossel::all();
        $revista = revista::where('id', '>', 0)->orderby('id', 'desc')->get();
        return view('revista')->with('revista', $revista)->with('carrossel',$carrossel);
    }
}