<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\professores;
use App\user;


class ProfessorController extends Controller
{
    public function deletar(Request $request) {
        $id = $request->id;
        $professor = professores::find($id);
        $professor->delete($id);
        return redirect()->action('Area_usuarioController@nivel');
    }
    public function deletarprofessor (Request $request){
        User::where('tipo', $request->nomeSala)->delete();
        return redirect()->action('ConfiguracoesController@validacprofessor');
    }
}
