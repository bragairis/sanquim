<?php

namespace App\Http\Controllers;
use Auth;
use Illuminate\Http\Request;
use App\professores;
use App\noticia;
use App\alunoscarrossel;
use App\msgpatrocinador;
use App\defhome;
use App\defsanquim;
use App\defpre_vestibular;
use App\defpre_vestibulinho;
use App\carrossel;
use App\footer;
use App\revista;
use App\imgRevista;
use App\user;
use App\horarios;
use App\simulados_vestibular;
use App\simulados_vestibulinho;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\SanquimRequest;
use App\Http\Requests\FooterRequest;
use App\Http\Requests\NoticiaRequest;
use App\Http\Requests\UserRequest;

class Area_usuarioController extends Controller
{

    public function nivel () {
       
        $role = Auth::user()->tipo;

    switch ($role){
        case 'administrador':
        $simulados_vestibular = simulados_vestibular::where('id', '>', 0)->orderby('id', 'desc')->limit('4')->get();
        $simulados_vestibulinho = simulados_vestibulinho::where('id', '>', 0)->orderby('id', 'desc')->limit('4')->get();
        $noticia = noticia::where('id', '>', 0)->orderby('id', 'desc')->get();
        $data = professores::all();
        $horarios = horarios::all();
        return view('areausuario-adm')->with('data', $data)->with('noticia', $noticia)
        ->with('simulados_vestibular', $simulados_vestibular)
        ->with('simulados_vestibulinho', $simulados_vestibulinho)->with('horarios', $horarios);
        
        case 'professor':
        $simulados_vestibular = simulados_vestibular::where('id', '>', 0)->orderby('id', 'desc')->limit('4')->get();
        $simulados_vestibulinho = simulados_vestibulinho::where('id', '>', 0)->orderby('id', 'desc')->limit('4')->get();
        $horarios = horarios::all();
        return view ('areausuario-prof')->with('simulados_vestibular', $simulados_vestibular)
        ->with('simulados_vestibulinho', $simulados_vestibulinho)->with('horarios', $horarios);

        case 'aluno':
        $simulados_vestibular = simulados_vestibular::where('id', '>', 0)->orderby('id', 'desc')->limit('4')->get();
        $simulados_vestibulinho = simulados_vestibulinho::where('id', '>', 0)->orderby('id', 'desc')->limit('4')->get();
        $professores = professores::all();
        $horarios = horarios::all();
        return view('areausuario')->with('professores', $professores)
        ->with('simulados_vestibular', $simulados_vestibular)
        ->with('simulados_vestibulinho', $simulados_vestibulinho)->with('horarios', $horarios);    

 }
   
}

    public function usersvestibular() {    
        $user = User::all();
        return view('alunosvestibular')->with('user', $user);
    }

    public function usersvestibulinho() {        
        $user = User::all();
        return view('alunosvestibulinho')->with('user', $user);
    }

    public function update_perfil(UserRequest $request)
    {
        $nameFile=null;
        if($request->hasFile('imagem') && $request->file('imagem')->isValid()) {
            $name = uniqid(date('HisYmd'));
            $extension = $request->imagem->extension();
            $nameFile = "{$name}.{$extension}";
            $upload = $request->imagem->storeAs('img/perfil', $nameFile);

            if (!$upload) {
                return redirect()->back()->with('error', 'Falha ao realizar o upload')->withInput();
            }

            $data = $request->all();        
            $user = user::find( Auth::user()->id );         
            $data['imagem'] = $nameFile;            
            $user->fill($data);        
            $user->save();        
            return redirect('/areausuario');
        }
    }

    public function download_horario($id)
    {
        $post = horarios::find($id);

        if(isset($post)){
            $path = Storage::disk('public') -> getDriver() -> getAdapter() -> applyPathPrefix($post ->arquivo);
            return response() -> download($path);
        }
        return redirect('/areausuario');
    }
}