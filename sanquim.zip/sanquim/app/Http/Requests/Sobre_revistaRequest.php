<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class Sobre_revistaRequest extends FormRequest {
    public function authorize() {
        return true;
    }

    public function rules() {
        return [
            'sobre' => 'required|min:5',
            'foto' => 'required',
            
          
        ];
    }

    public function messages() {
        return [
            'required' => 'O campo :attribute é obrigatório',
            'sobre.min' =>  'O campo sobre precisa ter no mínimo 5 caracteres',   
        ];
    }
}