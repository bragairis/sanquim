<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CarrosselRequest extends FormRequest {
    public function authorize() {
        return true;
    }

    public function rules() {
        return [
            'foto1' => 'required',
            'foto2' => 'required',
            'foto3' => 'required',  
        ];
    }

    public function messages() {
        return [
            'required' => 'O campo :attribute é obrigatório',
        ];
    }
}