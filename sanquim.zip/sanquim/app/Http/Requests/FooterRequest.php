<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class FooterRequest extends FormRequest {
    public function authorize() {
        return true;
    }

    public function rules() {
        return [
            'localizacao' => 'required|min:5',
            'horario' => 'required|min:5',
            'telefone' => 'required|min:8',
            'facebook' => 'required|min:8',
            'instagram' => 'required|min:8',
        ];
    }

    public function messages() {
        return [
            'required' => 'O campo :attribute é obrigatório',
            'localizacao.min' => 'O campo localizacao precisa ter no mínimo 5 caracteres',
            'horario.min' =>  'O campo horario precisa ter no mínimo 5 caracteres',
            'telefone.min' => 'A mensagem precisa ter no mínimo 8 caracteres',
            'facebook.min' =>  'O campo facebook precisa ter no mínimo 5 caracteres',
            'instagram.min' =>  'O campo instagram precisa ter no mínimo 5 caracteres',
        ];
    }
}