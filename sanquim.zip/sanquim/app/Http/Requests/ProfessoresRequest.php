<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProfessoresRequest extends FormRequest {
    public function authorize() {
        return true;
    }

    public function rules() {
        return [
            'nome' => 'required|min:2',
            'email' => 'required|min:5',
            'descricao' => 'required|min:5',
          
        ];
    }

    public function messages() {
        return [
            'required' => 'O campo :attribute é obrigatório',
            'nome.min' => 'O campo nome precisa ter no mínimo 2 caracteres',
            'email.min' =>  'O campo email precisa ter no mínimo 5 caracteres',
            'descricao.min' => 'A descrição precisa ter no mínimo 5 caracteres'
        ];
    }
}