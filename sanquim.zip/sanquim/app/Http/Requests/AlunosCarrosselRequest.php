<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AlunosCarrosselRequest extends FormRequest {
    public function authorize() {
        return true;
    }

    public function rules() {
        return [
            'nome' => 'required|min:2',
            'faculdade' => 'required|min:1',
            'mensagem' => 'required|min:10',
            'foto' => 'required',
          
        ];
    }

    public function messages() {
        return [
            'required' => 'O campo :attribute é obrigatório',
            'nome.min' => 'O campo título precisa ter no mínimo 2 caracteres',
            'faculdade.min' =>  'O campo subtítulo precisa ter no mínimo 1 caracteres',
            'mensagem.min' => 'A mensagem precisa ter no mínimo 5 caracteres'
        ];
    }
}