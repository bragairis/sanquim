<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class NoticiaRequest extends FormRequest {
    public function authorize() {
        return true;
    }

    public function rules() {
        return [
            'titulo' => 'required|min:2',
            'subtitulo' => 'required|min:5',
            'noticia' => 'required|min:10',
          
        ];
    }

    public function messages() {
        return [
            'required' => 'O campo :attribute é obrigatório',
            'titulo.min' => 'O campo título precisa ter no mínimo 2 caracteres',
            'subtitulo.min' =>  'O campo subtítulo precisa ter no mínimo 5 caracteres',
            'noticia.min' => 'A notícia precisa ter no mínimo 10 caracteres'
        ];
    }
}