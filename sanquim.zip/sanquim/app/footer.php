<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class footer extends Model {
    public $timestamps = false;
    protected $table = 'footer';
    protected $fillable = ['localizacao', 'horario', 'telefone', 'facebook', 'instagram'];
}