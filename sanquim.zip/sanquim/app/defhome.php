<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class defhome extends Model {
    public $timestamps = false;
    protected $table = 'defhome';
    protected $fillable = ['definicao'];
}