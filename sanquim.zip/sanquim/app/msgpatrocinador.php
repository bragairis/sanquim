<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class msgpatrocinador extends Model {
    protected $table = 'msgpatrocinador';
    protected $fillable = ['nome', 'email', 'assunto', 'mensagem'];
}