<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class alunoscarrossel extends Model {
    
    public $timestamps = false;
    protected $table = 'alunoscarrossel';
    protected $fillable = ['nome', 'faculdade', 'mensagem', 'foto'];
}