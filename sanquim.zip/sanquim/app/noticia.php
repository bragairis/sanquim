<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class noticia extends Model {
    
    public $timestamps = false;
    protected $table = 'noticia';
    protected $fillable = ['titulo','subtitulo', 'noticia','imagem' ];
}