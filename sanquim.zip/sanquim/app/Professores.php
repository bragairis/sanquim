<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class professores extends Model {
    
    public $timestamps = false;
    protected $table = 'professores';
    protected $fillable = ['foto', 'nome', 'disciplina', 'descricao', 'email'];
}