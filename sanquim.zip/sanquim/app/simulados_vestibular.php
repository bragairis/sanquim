<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class simulados_vestibular extends Model {
    
    public $timestamps = false;
    protected $table = 'simulados-vestibular';
    protected $fillable = ['dia'];
}