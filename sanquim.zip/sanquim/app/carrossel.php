<?php

namespace App;

use Illuminate\Database\Eloquent\Model;



class carrossel extends Model {
    public $timestamps = false;
    protected $table = 'carrossel';
    protected $fillable = ['foto1', 'foto2', 'foto3'];
}