jQuery(window).on('load', function (e) {
  $(".loader").delay(1000).fadeOut("slow"); 
$("#page-secundaria").toggle("fast");
});
