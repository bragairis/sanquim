<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>

<div class="row">
        <div class="page-header">   
           <img class="w-100" src="\storage\img\noticia\<?php echo e($noticia->imagem); ?>">
        </div>
    </div>
    
<div class="main main-raised" >
    
        <div class="card card-signup">
        <div class="card-header card-header-primary text-center">
                <h3><?php echo e($noticia->titulo); ?></h3> 
        </div>
    
    <div class="section section-contacts">
            <div class="row">
                <div class="col-md-6 ml-auto mr-auto">
                    <h2 class="text-center"><?php echo e($noticia->subtitulo); ?></h2>
                    <h4 class="text-center"><?php echo e($noticia->noticia); ?></h4>
                    
                </div>
        
        </div>

</div>
 

    <div class="main main-raised">
       
    </div>
    </div>
    </div>
    <!-- 	            end nav tabs -->
   



       <?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>