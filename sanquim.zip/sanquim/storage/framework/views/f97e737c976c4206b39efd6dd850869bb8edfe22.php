<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>
    

<div class="row" >
  <div class="section section-signup " style="padding-top: 100px; width: 100%; background-position: center center; background-size: cover; margin: 0; border: 0;     display: flex;
      align-items: center; background-image: url('/img/capalogin.png');">   
  <div class="space"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto col-146">
            <div class="card card-signup">
              <div class="card-header card-header-primary text-center">
                <h4>PROFESSORES</h4>                  
              </div>
            <br>
            <br>
              <div id="accordion">
                  <div class="">
                                <div class="card-header" id="headingOne">
                                    <div class="row">
                                        <h5 class="col-sm-9">
                                        <div class="btn btn-link"  aria-expanded="true" aria-controls="">Professores</div>
                                        </h5>
                                        <div class="col-sm-3">
                                        <form action="/deletar/professor" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_method" value="delete" />
                                            <input type="hidden" name="nomeSala" value="Professor" />
                                            <button rel="tooltip" class="btn ">Limpar Lista</button>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                            <div class="card-body">
                                                <table class="table">
                                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($p->tipo == 'professor'): ?>
                                                        <tr>
                                                            <td class="view-message col-sm-9">
                                                                <form action="/validacao/deletarrr/<?php echo e($p->id); ?>" method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="_method" value="delete" />
                                                                    <i ></i>
                                                                    <button rel="tooltip" class="btn btn-warning"><i class="material-icons">close</i></button>
                                                                    <?php echo e($p->name); ?>

                                                                
                                                                </form>
                                                                
                                                                <div class="modal fade" id="<?php echo e($p->id); ?>" tabindex="-1" role="dialog" aria-labelledby="<?php echo e($p->id); ?>Label" aria-hidden="true">
                                                                   
                                                                    <div class="modal-dialog" role="document">
                                                                        <div class="modal-content">
                                                                            <div class="modal-header">
                                                                                    <h5 class="modal-title" id="<?php echo e($p->id); ?>Label">Dados do professor(a) <?php echo e($p->name); ?></h5>
                                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                                    <span aria-hidden="true">&times;</span>
                                                                                </button>
                                                                            </div>
                                                                            <div class="modal-body">
                                                                                <h4> Nome:</h4><h5><?php echo e($p->name); ?></h5> <br>
                                                                                <h4>Telefone:</h4><h5><?php echo e($p->telefone); ?></h5> <br>
                                                                                <h4>Email:</h4><h5><?php echo e($p->email); ?></h5> <br>
                                                                                <h4>Criado em:</h4><h5><?php echo e($p->created_at); ?></h5>

                                                                            </div>
                                                                        </div>
                                                                    </div> 
                                                                </div>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
                                                                  
                                                            </td>
                                                            <td class="col-sm-2"> <button type="button" class="btn  btn-labeled btn-success " href="#" style="" data-toggle="modal" data-target="#<?php echo e($p->id); ?>">Dados</button></td>
                                                        </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </table>       
                                            </div>
                                        </div>
                            </div>
            


                            </div> 
                
                

               <div class="space"></div>
              </div>



            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>
</div>
</div>
       <?php $__env->stopSection(); ?>






<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>