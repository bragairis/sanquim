<?php $__env->startSection('conteudo'); ?>

  

<div class="row">
<div class="section section-signup page-header" style="background-image: url('/img/ws_Mountain_View_1280x720.jpg');">
<link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen"> 
    
            <div class="container">
                <div class="row user-menu-container square">
                <div class="col-md-7 user-details">
                        <div class="row coralbg white">
                            <div class="col-md-6 no-pad">
                                <div class="user-pad">
                                    <h3>Bem-Vindo, Marcos!</h3>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibular</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma A</h4>
                                    
                                </div>
                            </div>
                            <div class="col-md-6 no-pad">
                                <!-- <div class="user-image"> isso aq vai deixar num tamanho padrao, dps resolver isso-->
                                    <img src="img/avatar/professores/avatar.jpg" class="img-responsive thumbnail">
                                <!-- </div> -->
                            </div>
                        </div>
                        <div class="row overview">
                            <div class="col-md-4 user-pad text-center">
                            </div>
                            <div class="col-md-8 user-pad text-center" style="color:#FA396F;">
                               <h3> " A nicole fede a iorgute - Freire,Paulo " </h3>
                            </div>
                        </div>
                    </div>



                    <div class="col-md-1 user-menu-btns">
                        <div class="btn-group-vertical square" id="responsive">
                            <a href="#" class="btn btn-block btn-default active">
                            <i class="fa fa-bell-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-envelope-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-laptop fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-cloud-upload fa-3x"></i>
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-md-4 user-menu user-pad">
                        <div class="user-menu-content active">
                            <h3>
                                Simulados
                            </h3>
                            <ul class="user-menu-list">
                                <li>
                                    <h4><i class="fa  fa-chevron-right  coral"></i> 23/06/2018</h4>
                                </li>
                                <li>
                                    <h4><i class="fa fa-chevron-right coral"></i> 23/06/2018</h4>
                                </li>
                                <li>
                                    <h4><i class="fa fa-chevron-right coral"></i> 23/06/2018</h4>
                                </li>
                                <li>
                                    <h4><i class="fa fa-chevron-right coral"></i> 23/06/2018</h4>
                                </li>
                                
                            </ul>
                        </div>
                        <div class="user-menu-content">
                            <h2 class="text-center">
                                HORÁRIOS
                            </h2>
                            <h4 class="text-center">Veja o horário das aulas dessa semana!</h4>
                            <center><i class="fa fa-cloud-upload fa-4x"></i></center>
                            <div class="share-links">
                                <center><button type="button" class="btn btn-lg btn-labeled btn-success" href="#" style="margin-bottom: 15px;" data-toggle="modal" data-target="#horarios">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Baixar Horários
                                </button></center>
                            </div>
                        </div>
                        <div class="scroll user-menu-content">
                            <h3>
                                Alunos
                            </h3>
                            <div class="share-links">
                                <center><a  class="btn btn-lg btn-labeled btn-info" href="/alunosvestibular" style="margin-bottom: 15px;">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibular
                                </a></center>
                                <center><a  class="btn btn-lg btn-labeled btn-primary" href="/alunosvestibulinho" >
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibulinho
                                </a></center>
                            </div>
                        </div>
                       
                        
                        <div class="user-menu-content">
                            <h2 class="text-center">
                                MATERIAL DE APOIO
                            </h2>
                            <h4 class="text-center">Otimize seu aprendizado em casa!</h4>
                            <center><i class="fa fa-cloud-upload fa-4x"></i></center>
                            <div class="share-links">
                                <center><button type="button" class="btn btn-lg btn-labeled btn-success" href="#" style="margin-bottom: 15px;" data-toggle="modal" data-target="#downloads">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibular
                                </button></center>
                                <center><button type="button" class="btn btn-lg btn-labeled btn-warning" href="#" data-toggle="modal" data-target="#exampleModal">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibulinho
                                </button></center>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="space-50"></div>

</div>

<!-- Modal -->
<!-- horarioss -->
<div class="modal fade" id="horarios"tabindex="-1" role="dialog" aria-labelledby="horariosLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="horariosLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

    </div>
  </div>
</div> 
</div>
<!-- /horarioss -->

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Material de apoio: Pré-Vestibulinho
       </button>
    </div>
  </div>
</div> 
</div>

<div class="modal fade" id="downloads" tabindex="-1" role="dialog" aria-labelledby="downloadsLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="downloadsLabel">Material de Apoio</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Material de apoio: Pré-Vestibular 
       </button>
      </div>
    </div>
  </div>
</div> 

<div class="modal fade" id="salasvestibular" tabindex="-1" role="dialog" aria-labelledby="salasvestibular" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="/alunosvestibular">
        Material de apoio: Pré-Vestibulinho
       </button>
    </div>
  </div>
</div> 
</div>

<div class="modal fade" id="salasvestibulinho" tabindex="-1" role="dialog" aria-labelledby="salasvestibulinho" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Material de apoio: Pré-Vestibulinho
       </button>
    </div>
  </div>
</div> 
</div>

</div>
</div>
<script>
			$(function () { // wait for document ready
				// init controller
				var controller1 = new ScrollMagic.Controller({container: "#container1"});

			});
		</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.principallogado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>