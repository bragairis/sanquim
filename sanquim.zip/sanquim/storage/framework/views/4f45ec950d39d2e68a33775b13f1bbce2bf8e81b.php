  

<?php $__env->startSection('conteudo'); ?>

  
  
  <div class="section section-signup " style="padding-top: 100px; width: 100%; background-position: center center; background-size: cover; margin: 0; border: 0;     display: flex;
      align-items: center; background-image: url('/img/capalogin.png');">
 <div class="space"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto col-146">
            <div class="card card-signup">
              <form class="form" method="" action="">
                  <div class="card-header card-header-primary text-center">
                  <h4>PRÉ-VESTIBULAR</h4>                  
                    </a>                
                </div>                           
                <div class="card-body">
                    <table class="table">
                        <head>
                            <tr>
                                
                                <th><div class="dropdown">
                                    <a class="btn btn-secondary " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala A
                                    </a>
                                  </div>
                                </th>
                            </tr>
                        </head>
                        <body>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->sala == 'Vestibular A'): ?>
                            <tr> 
                                <td><?php echo e($p->name); ?> <?php echo e($p->sobrenome); ?></td>
                            </tr>
                            
                            
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </body>
                    </table>
<!-- fim sala a tabela A -->         
            
                <table class="table">
                    <head>
                    <tr>
                                
                                <th><div class="dropdown">
                                    <a class="btn btn-secondary " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala B
                                    </a>
                                  </div>
                                </th>
                            </tr>
                        </head>
                        <body>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->sala == 'Vestibular B'): ?>
                            <tr> 
                                <td><?php echo e($p->name); ?></td>
                            </tr>
                            
                            
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </body>
                    </table>
                    <!-- fim sala a tabela B  -->         
            
                <table class="table">
                    <head>
                    <tr>
                                
                                <th><div class="dropdown">
                                    <a class="btn btn-secondary " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala C
                                    </a>
                                  </div>
                                </th>
                            </tr>
                        </head>
                        <body>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->sala == 'Vestibular C'): ?>
                            <tr> 
                                <td><?php echo e($p->name); ?></td>
                            </tr>
                            
                            
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </body>
                    </table>
                    <!-- fim sala a tabela C -->         
            
                <table class="table">
                    <head>
                    <tr>
                                
                                <th><div class="dropdown">
                                    <a class="btn btn-secondary " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala D
                                    </a>
                                  </div>
                                </th>
                            </tr>
                        </head>
                        <body>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->sala == 'Vestibular D'): ?>
                            <tr> 
                                <td><?php echo e($p->name); ?></td>
                            </tr>
                            
                            
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </body>
                    </table>

 <!-- fim sala a tabela D -->   

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>