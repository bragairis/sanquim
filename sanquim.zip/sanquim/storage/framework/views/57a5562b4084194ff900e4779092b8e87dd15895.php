<?php $__env->startSection('conteudo'); ?>

 <div class="row">
    <div class="section section-signup page-header" style="background-image: url('/img/capalogin.png');">
      <div class="container">
        <div class="row">
        <div class="col-md-4 ml-auto mr-auto">
            <div class="card card-signup">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="card-header card-header-primary text-center">
                  <h4><?php echo e(__('Entrar')); ?></h4>                  
                    </a>                
                </div>                           
                <div class="card-body">
                        <div class="input-group">
                                <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="material-icons">face</i>
                            </span>
                            </div>
                                <input id="email" type="email" placeholder="Email..." class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            
                        </div>

                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="material-icons">lock_outline</i>
                            </span>
                            </div>
                                <input id="password" type="password" placeholder="Senha..." class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                          
                        </div>

                        <div class="card-footer justify-content-center row">
                            
                                <button type="submit" class="btn btn-primary btn-round">
                                    <?php echo e(__('Login')); ?>

                                </button>
                           
                            </div>
                        </div>
                        <div class="card-footer justify-content-center">
                    <div class="cd-section">
                        <div class="title">
                                <h4>
                                    <small>Possui conta?</small>   
                                <br>
                                    <small>Não? Então...</small>
                                    </h4>                            
                        </div>
                    </div>  
                </div>    
                    <div class="card-footer justify-content-center">    

                       <a href="/register" class="btn btn-primary btn-sm">Cadastre-se</a>               
                    </div>    
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
      <!-- footer -->
     
    </div>
     </div>
</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>