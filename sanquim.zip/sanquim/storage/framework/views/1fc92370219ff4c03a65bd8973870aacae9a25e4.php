<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>

<div class="row">
 <div class="section section-signup page-header" style="background-image: url('/img/ws_Mountain_View_1280x720.jpg'); ">
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto col-xl-6">
            <div class="card card-signup">
              <form class="form" method="" action="">
                  <div class="card-header card-header-primary text-center">
                  <h4>Cadastro</h4>                  
                    </a>                
                </div>                           
                <div class="card-body">
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="material-icons">face</i>
                      </span>
                    </div>
                    <input type="text" class="form-control" placeholder="Nome completo">
                  </div>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="material-icons">email</i>
                      </span>
                    </div>
                    <input type="email" class="form-control" placeholder="EX: sanquim@gmail.com">
                  </div>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="material-icons">lock_outline</i>
                      </span>
                    </div>
                    <input type="password" class="form-control" placeholder="Senha">    
                  </div>
                   <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="material-icons">call_end</i>
                      </span>
                    </div>
                    <input type="text" class="form-control" placeholder="EX: 999-9999">    
                  </div>
                  <br>
   
   <div class="form-check form-check-radio form-check-inline">
  <label class="form-check-label">
    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"> Aluno
    <span class="circle">
        <span class="check"></span>
    </span>
  </label>
</div>
<div class="form-check form-check-radio form-check-inline">
  <label class="form-check-label">
    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2"> Professor
    <span class="circle">
        <span class="check"></span>
    </span>
  </label>
</div>
<div class="form-check form-check-radio form-check-inline">
  <label class="form-check-label">
    <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3"> Administrador
    <span class="circle">
        <span class="check"></span>
    </span>
  </label>
  <ul class="nav nav-pills form-check form-check-radio form-check-inline">
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Sala</a>
    <div class="dropdown-menu">
      <a class="dropdown-item" href="#">1</a>
      <a class="dropdown-item" href="#">2</a>
      <a class="dropdown-item" href="#">3</a>
      </ul>
      </div>

         </div>
          
                <div class="card-footer justify-content-center">
                    <div class="cd-section">
                        
                    </div>  
                </div>    
                    <div class="card-footer justify-content-center">    
                        <button class="btn btn-primary btn-sm" href="/cadastro">
                             Cadastrar
                        </button>                      
                    </div>
                    
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
     <div class="space-50"></div>
    </div>
</div>
      <?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>