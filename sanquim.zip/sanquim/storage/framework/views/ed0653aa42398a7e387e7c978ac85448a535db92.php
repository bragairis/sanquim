<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>
        <!--/menu-->
        <!--carrosel principal-->
        <div class="row">
            <div class="page-header">
                <div class="card card-raised card-carousel">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators" data-slide-to="0" class=""></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                            <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item">
                                <img class="w-100" src="/img/bg3.jpg" alt="First slide">
                                <div class="carousel-caption d-none d-md-block">
                                    <h4>
                                        <i class="material-icons">location_on</i> Yellowstone National Park, United States
                                    </h4>
                                </div>
                            </div>
                            <div class="carousel-item active">
                                <img class="w-100" src="/img/bg.jpg" alt="Second slide">
                                <div class="carousel-caption d-none d-md-block">
                                    <h4>
                                        <i class="material-icons">location_on</i> Somewhere Beyond, United States
                                    </h4>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <img class="w-100" src="/img/bg2.jpg" alt="Third slide">
                                <div class="carousel-caption d-none d-md-block">
                                    <h4>
                                        <i class="material-icons">location_on</i> Yellowstone National Park, United States
                                    </h4>
                                </div>
                            </div>
                        </div>
                        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <i class="material-icons">keyboard_arrow_left</i>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <i class="material-icons">keyboard_arrow_right</i>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!--/carrosel principal-->

        <div class="main main-raised ">
            <div class="section">
                



                <div class="container">
                    <div class="row text-center">
                        <div class="col-md-8 ml-auto mr-auto">
                            <h2>O que é o Curso Pré-Vestibular?</h2>
                            <h4>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean tempor at purus porttitor elementum. Pellentesque nec leo
                                vel ligula pulvinar varius sit amet eu justo. Aenean vitae imperdiet dolor. Nulla nec arcu
                                sit amet erat euismod bibendum in non ipsum. Sed ut ipsum viverra, consectetur diam nec,
                                sagittis ligula. Cras suscipit lectus ante, euismod aliquet ante facilisis eu. Quisque pulvinar
                                diam ac libero imperdiet bibendum. Nulla aliquam nulla at nisi pellentesque, quis volutpat
                                ex cursus. Mauris id vehicula turpis. Vestibulum ut rhoncus ante. Curabitur ullamcorper nunc
                                a lorem fringilla, ac convallis ipsum eleifend. Sed malesuada rutrum eros, ac vehicula orci
                                interdum eget. Pellentesque accumsan ut odio a ultricies. Nam varius tempor orci vitae convallis.
                                Ut quis efficitur mauris, nec tincidunt orci. Nam eu lobortis mi, sed luctus nulla. Maecenas
                                mi ligula, maximus sed auctor volutpat, dapibus eu ipsum. Morbi pellentesque eu est vel sodales.
                                Pellentesque non vulputate urna, ut dictum purus. Aliquam sed blandit lacus. Integer gravida
                                quis leo id fringilla. Curabitur eu justo sit amet quam molestie blandit. Mauris placerat
                                pulvinar risus, eu tempor sapien.
                            </h4>
                            <a href="/contato" class="btn btn-primary btn-lg">Entre em contato</a>

                            <h2>Galeria dos Alunos</h2>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="space-50"></div>

        <!-- footer -->
  
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>