<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>
    

 <div class="" style="background-color:#033288;">   
 <div class="space"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto col-146">
            <div class="card card-signup">
              <form class="form" method="" action="">
                  <div class="card-header card-header-primary text-center">
                  <h4>Criação de Noticias</h4>                  
                    </a>                
                </div>                           
                <div class="card-body">
                    <form>
                        <div class="form-group">
                          <label for=></label><h5>Titulo da Noticia</h5></label>
                          </div>
                        
                        <input type="text" name="Nome" size="80" /> 
                        
                        
                        <div class="form-group">
                          <label></label><h5>Subtítulo</h5></label>
                         </div>
                          <input type="text" name="Nome" size="80" /> 
                        
                        
                      
                        <div class="form-group">
                          <label></label><h5>Area de texto</h5></label>
                          <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                        </div>
                      </form>
                    
                     
                     
                     
                      <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                       
                        <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                        <div>
                        <span class="btn btn-raised btn-round btn-default btn-file">
                            <span class="fileinput-new">Adicionar Foto</span>
                        <input type="file" id="input-file-now" class="dropify" /></span>
                            <br />
                            <button type="button" class="btn btn-primary">Concluir</button>
                        </div>
                    </div>
                    </div>
                </div>
            
<!-- fim sala a tabela -->         
            
 


              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>
    </div>




        <!-- 	            end nav tabs -->
        <div class="section section-white">
            <div class="container">
             
           
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="material-icons">clear</i>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link">Nice Button</button>
                    <button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!--  End Modal -->
     <?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principallogado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>