<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>
    
<div class="" style="background-color:#033288;">  
 <div class="space"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto col-146">
            <div class="card card-signup">
              <form class="form" method="" action="">
                  <div class="card-header card-header-primary text-center">
                  <h4>PRE-VESTIBULINHO</h4>                  
                    </a>                
                </div>                           
                <div class="card-body">
                    <table class="table">
                        <head>
                            <tr>
                                
                                <th><div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala A
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                      <a class="dropdown-item" href="#">Resetar Sala A</a>                
                                    </div>
                                  </div>
                                </th>
                               
                                <th class="text-right">Ações</th>
                            </tr>
                        </head>
                        <body>
                            <tr>
                                
                                <td>Andrew Mike</td>

                                
                                <td class="td-actions text-right">
                                   
                                    <button type="button" class="btn btn-success">
                                    <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                    <button type="button" rel="tooltip" class="btn btn-danger">
                                        <i class="material-icons">close</i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                
                                <td>John Doe</td>

                                
                                <td class="td-actions text-right">
                                   
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                        </button>
                                    <button type="button" rel="tooltip" class="btn btn-danger">
                                        <i class="material-icons">close</i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                
                                <td>Alex Mike</td>
 
                                
                                <td class="td-actions text-right">
                                   
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                        </button>
                                    <button type="button" rel="tooltip" class="btn btn-danger">
                                        <i class="material-icons">close</i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                
                                <td>Peter Jhow</td>

                                
                                <td class="td-actions text-right">
                                    <button type="button" rel="tooltip" class="btn btn-warning">
                                        <i class="fa fa-trash" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                        </body>
                    </table>
<!-- fim sala a tabela -->         
            
                <table class="table">
                    <head>
                        <tr>
                            
                            <th><div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                  Sala B
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                  <a class="dropdown-item" href="#">Resetar Sala B</a>                
                                </div>
                              </div>
                            </th>
                           
                            <th class="text-right">Ações</th>
                        </tr>
                    </head>
                    <body>
                        <tr>
                            
                            <td>Andrew Mike</td>

                            
                            <td class="td-actions text-right">
                                
                                <button type="button" class="btn btn-success">
                                    <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                <button type="button" rel="tooltip" class="btn btn-danger">
                                    <i class="material-icons">close</i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            
                            <td>John Doe</td>

                            
                            <td class="td-actions text-right">
                               
                                <button type="button" class="btn btn-success">
                                    <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                <button type="button" rel="tooltip" class="btn btn-danger">
                                    <i class="material-icons">close</i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                            
                            <td>Alex Mike</td>

                            
                            <td class="td-actions text-right">
                               
                                <button type="button" class="btn btn-success">
                                    <i class="fa fa-check" aria-hidden="true"></i>
                                    </button>
                                <button type="button" rel="tooltip" class="btn btn-danger">
                                    <i class="material-icons">close</i>
                                </button>
                            </td>
                        </tr>
                        <tr>
                                
                            <td>Peter Jhow</td>

                            
                            <td class="td-actions text-right">
                                <button type="button" rel="tooltip" class="btn btn-warning">
                                    <i class="fa fa-trash" aria-hidden="true"></i>
                                </button>
                            </td>
                        </tr>
                    </body>
                </table>
<!-- fim da tabela b -->
                
                    <table class="table">
                        <head>
                            <tr>
                                
                                <th><div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala C
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                      <a class="dropdown-item" href="#">Resetar Sala C</a>                
                                    </div>
                                  </div>
                                </th>
                               
                                <th class="text-right">Ações</th>
                            </tr>
                        </head>
                        <body>
                            <tr>
                                
                                <td>Andrew Mike</td>
    
                                
                                <td class="td-actions text-right">
                                   
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                        </button>
                                    <button type="button" rel="tooltip" class="btn btn-danger">
                                        <i class="material-icons">close</i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                
                                <td>John Doe</td>
    
                                
                                <td class="td-actions text-right">
                                    
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                        </button>
                                    <button type="button" rel="tooltip" class="btn btn-danger">
                                        <i class="material-icons">close</i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                
                                <td>Alex Mike</td>
    
                                
                                <td class="td-actions text-right">
                                  
                                    <button type="button" class="btn btn-success">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                        </button>
                                    <button type="button" rel="tooltip" class="btn btn-danger">
                                        <i class="material-icons">close</i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                
                                <td>Peter Jhow</td>

                                
                                <td class="td-actions text-right">
                                    <button type="button" rel="tooltip" class="btn btn-warning">
                                        <i class="fa fa-trash" aria-hidden="true"></i>
                                    </button>
                                </td>
                            </tr>
                        </body>
                    </table>
                    <!-- fim da tabela c -->
                </div>


              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>
    </div>

           
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="material-icons">clear</i>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-link">Nice Button</button>
                    <button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!--  End Modal -->
       
 

    <!--   Core JS Files   -->
    <script src="./assets/js/core/jquery.min.js"></script>
    <script src="./assets/js/core/popper.min.js"></script>
    <script src="./assets/js/bootstrap-material-design.js"></script>
    <!--  Plugin for Date Time Picker and Full Calendar Plugin  -->
    <script src="./assets/js/plugins/moment.min.js"></script>
    <!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
    <script src="./assets/js/plugins/bootstrap-datetimepicker.min.js"></script>
    <!--	Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="./assets/js/plugins/nouislider.min.js"></script>
    <!-- Material Kit Core initialisations of plugins and Bootstrap Material Design Library -->
    <script src="./assets/js/material-kit.js?v=2.0.2"></script>
    <!-- Fixed Sidebar Nav - js With initialisations For Demo Purpose, Don't Include it in your project -->
    <script src="./assets/assets-for-demo/js/material-kit-demo.js"></script>
    <script>
        $(document).ready(function() {

            //init DateTimePickers
            materialKit.initFormExtendedDatetimepickers();

            // Sliders Init
            materialKit.initSliders();
        });
    </script>
       <?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principallogado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>