<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>

<div class="row">
        <div class="page-header">   
           <img class="w-100" src="/img/patrocinadores2aa.png" >
        </div>
    </div>
    <div class="main main-raised">
        <div class="">

            <!-- conteudo -->

     <div class="space-50"></div>
            <div class="container-fluid" >

                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 project project-1 wow animated animated4 fadeInLeft" style="background-image: url('/img/abapatrocinador1.png');" >
                        
                        <div class="project-hover" >
                            <h2>O que é ser um patrocinador?</h2>
                            <hr />
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pulvinar ex pulvinar est laoreet ullamcorper.QUER SABER MASI SOBRE NÓS? </p>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 project project-4 wow animated fadeInLeft" style="background-image: url('/img/abaspatrocinador2.png');">
                        <div class="project-hover">
                            <h2>Porque ser?</h2>
                            <hr />
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pulvinar ex pulvinar est laoreet ullamcorper.</p>
                            <a href="/index">Clique aqui! </a>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 project project-3 wow animated animated2 fadeInLeft" style="background-image: url('/img/abapatrocinador3.png');">
                        <div class="project-hover">
                            <h2>Como se tornar um:</h2>
                            <hr />
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pulvinar ex pulvinar est laoreet ullamcorper.</p>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 project project-4 wow animated fadeInLeft" style="background-image: url('/img/abapatrocinador4.png');">
                        <div class="project-hover">
                            <h2>Entre em contato</h2>
                            <hr />
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas pulvinar ex pulvinar est laoreet ullamcorper.</p>
                            <a href="/contato">Clique aqui! </a>
                        </div>
                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="space-50"></div>
    </div>    

        <div class="row bg-white">
            <div class="col-md-12">
                
<?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>