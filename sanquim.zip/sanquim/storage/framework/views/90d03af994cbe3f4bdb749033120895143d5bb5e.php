<html lang="en">


<?php $__env->startSection('conteudo'); ?>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <!--carrosel principal-->
    <div class="row">
        <div class="page-header">
            <div class="card card-raised card-carousel">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class=""></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item">
                            <img class="w-100" src="/img/bg3.jpg" alt="First slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Yellowstone National Park, United States
                                </h4>
                            </div>
                        </div>
                        <div class="carousel-item active">
                            <img class="w-100" src="/img/bg.jpg" alt="Second slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Somewhere Beyond, United States
                                </h4>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img class="w-100" src="/img/bg2.jpg" alt="Third slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Yellowstone National Park, United States
                                </h4>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <i class="material-icons">keyboard_arrow_left</i>
                            <span class="sr-only">Previous</span>
                          </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <i class="material-icons">keyboard_arrow_right</i>
                            <span class="sr-only">Next</span>
                          </a>
                </div>
            </div>
        </div>
    </div>
    <!--/carrosel principal-->
    
    <div class="main main-raised ">
        


      <div class="container">
        <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css'>
            <div class="mail-box">
                  <aside class="lg-side">    
                      <div class="inbox-body">
                          <table class="table table-inbox table-hover">
                            <tbody>
                              <tr class="unread">

                                  <td class="view-message  dont-show">PHPClass</td>
                                  <td class="view-message ">Added a new class: Login Class Fast Site</td>
                           
                                  <td class="view-message  text-right">9:27 AM</td>
                              </tr>
                              
                          </tbody>
                          </table>
                      </div>
                  </aside>
              </div>
            </div>
      </div>
    </div>

   
        
    <div class="space-50"></div>

    <!--/footer-->
 
</body>

</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>