<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>
        <!--/menu-->
        <!--carrosel principal-->
        <div class="row">
    <div class="page-header">
        <div class="card card-raised card-carousel" style="margin-top: 0px; margin-bottom: 0px;">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class=""></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                </ol>
                <div class="carousel-inner">
                    <!-- IMAGEM TEM Q TER TAMANHO DE 1366X768 OU 1280X720-->
                    <div class="carousel-item active">
                        <img class="w-100" src="/img/ws_Mountain_View_1280x720.jpg" alt="First slide">
                        <div class="carousel-caption d-none d-md-block">
                            <h4>
                                <i class="material-icons">location_on</i> Yellowstone National Park, United States
                            </h4>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="/img/capat.png" alt="Second slide">
                        <div class="carousel-caption d-none d-md-block">
                            <h4>
                                <i class="material-icons">location_on</i> Somewhere Beyond, United States
                            </h4>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="/img/bg3.jpg" alt="Third slide">
                        <div class="carousel-caption d-none d-md-block">
                            <h4>
                                <i class="material-icons">location_on</i> Yellowstone National Park, United States
                            </h4>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <i class="material-icons">keyboard_arrow_left</i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <i class="material-icons">keyboard_arrow_right</i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
        <!--/carrosel principal-->

        <div class="main main-raised ">
            <div class="section">
                



                <div class="container">
                    <div class="row text-center">
                        <div class="col-md-8 ml-auto mr-auto">
                        <?php $__currentLoopData = $defpre_vestibulinho; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h2>O que é o Curso Pré-Vestibulinho?</h2>
                            <h4><?php echo e($p->definicao); ?></h4>
                            <a href="/contato" class="btn btn-primary btn-lg">Entre em contato</a>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="space-50"></div>

        <!-- footer -->
  
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>