  

<?php $__env->startSection('conteudo'); ?>


  <div class="section section-signup " style="padding-top: 100px; width: 100%; background-position: center center; background-size: cover; margin: 0; border: 0;     display: flex;
      align-items: center; background-image: url('/img/capalogin.png');">
 <div class="space"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto col-146">
            <div class="card card-signup">
              <form class="form" method="" action="">
                  <div class="card-header card-header-primary text-center">
                  <h4>PRÉ-VESTIBULINHO</h4>                  
                    </a>                
                </div>                           
                <div class="card-body">
                    <table class="table">
                        <head>
                            <tr>
                                
                                <th><div class="dropdown">
                                    <a class="btn btn-secondary " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala A
                                    </a>
                                  </div>
                                </th>
                            </tr>
                        </head>
                       
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->sala == 'Vestibulinho A'): ?>
                            <tr> 
                                <td><?php echo e($p->name); ?></td>
                            </tr>
                            
                            
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </table>
<!-- fim sala a tabela a -->         
            
                <table class="table">
                   
                    <tr>
                                
                                <th><div class="dropdown">
                                    <a class="btn btn-secondary " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala B
                                    </a>
                                  </div>
                                </th>
                            </tr>
                       
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->sala == 'Vestibulinho B'): ?>
                            <tr> 
                                <td><?php echo e($p->name); ?></td>
                            </tr>
                            
                            
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </table>
<!-- fim da tabela b -->
<table class="table">
                   
                    <tr>
                                
                                <th><div class="dropdown">
                                    <a class="btn btn-secondary " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala C
                                    </a>
                                  </div>
                                </th>
                            </tr>
                       
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->sala == 'Vestibulinho C'): ?>
                            <tr> 
                                <td><?php echo e($p->name); ?></td>
                            </tr>
                            
                            
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                    </table>
            <!-- fim tabela c -->
            <table class="table">
                   
                    <tr>
                                
                                <th><div class="dropdown">
                                    <a class="btn btn-secondary " data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      Sala D
                                    </a>
                                  </div>
                                </th>
                            </tr>
                       
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->sala == 'Vestibulinho D'): ?>
                            <tr> 
                                <td><?php echo e($p->name); ?></td>
                            </tr>
                            
                            
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </table>
                <!-- fim tabela d -->
                   
                </div>


              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>