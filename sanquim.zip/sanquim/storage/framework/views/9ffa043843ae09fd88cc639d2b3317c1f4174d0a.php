<?php $__env->startSection('conteudo'); ?>

<div class="row" >
  <div class="section section-signup " style="padding-top: 100px; width: 100%; background-position: center center; background-size: cover; margin: 0; border: 0;     display: flex;
      align-items: center; background-image: url('/img/capalogin.png');">
        <div class="container">
            <div class="row">
                <div class="col-md-8 ml-auto mr-auto col-xl-8">
                    <div class="card card-signup">
                            <form method="post" action="/update-perfil" enctype="multipart/form-data">
                                <div class="card-header card-header-primary text-center">
                                    <h4>Editar Perfil</h4>     
                                </div> 
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="input-group"><h4>Nome</h4>  
                                                <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="material-icons">face</i>
                                                </span>
                                                </div>
                                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(Auth::user()->name); ?>" >
                                                
                                                <?php if($errors->has('name')): ?>
                                                    <span class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                        
                                    </div>
                                    <div class="input-group"><h4>Sobrenome</h4>  
                                                <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="material-icons">face</i>
                                                </span>
                                                </div>
                                                <input id="sobrenome" type="text" class="form-control<?php echo e($errors->has('sobrenome') ? ' is-invalid' : ''); ?>" name="sobrenome" value="<?php echo e(Auth::user()->sobrenome); ?>" >
                                                <?php if($errors->has('sobrenome')): ?>
                                                    <span class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('sobrenome')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                        
                                    </div>
                                    <div class="input-group"><h4>E-mail</h4>  
                                            <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">email</i>
                                            </span>
                                            </div>
                                            <input id="email" type="email" placeholder="EX: sanquim@gmail.com" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(Auth::user()->email); ?>" >

                                            <?php if($errors->has('email')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                    
                                    </div>
                                    
                                    <div class="input-group"><h4>Telefone</h4>  
                                        <div class="input-group-prepend">
                                        <span class="input-group-text">
                                        <i class="material-icons">call_end</i>
                                        </span>
                                        </div>
                                                    <input id="telefone" type="telefone" placeholder="EX: 999-9999" class="form-control <?php echo e($errors->has('telefone') ? ' is-invalid' : ''); ?>" name="telefone" value="<?php echo e(Auth::user()->telefone); ?>" placeholder="EX: 999-9999">
                    
                                                    <?php if($errors->has('telefone')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('telefone')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            
                                    </div>
                                    
                                    <div class="input-group">
                                        <div class=""><h4>Foto</h4>
                                            <div class="container" style="padding-left: 90px;">
                                                <h4  style="color: #8b8b8b;" >Utilize uma foto que possamos te identificar!</h5>
                                                <input type="file" name="imagem">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer justify-content-center">    
                                        <button class="btn btn-primary btn-sm" type="submit" >
                                            <?php echo e(__('Editar')); ?>

                                        </button>
                                    </div>
                            
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
</div>
</Div>
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>