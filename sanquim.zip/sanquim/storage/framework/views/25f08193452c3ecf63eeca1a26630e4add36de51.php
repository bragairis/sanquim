<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>



    <div class="row">
        <div class="page-header">
            <div class="card card-raised card-carousel">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class=""></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item">
                            <img class="w-100" src="/img/bg2.jpg" alt="First slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Yellowstone National Park, United States
                                </h4>
                            </div>
                        </div>
                        <div class="carousel-item active">
                            <img class="w-100" src="/img/bg3.jpg" alt="Second slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Somewhere Beyond, United States
                                </h4>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img class="w-100" src="/img/bg.jpg" alt="Third slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Yellowstone National Park, United States
                                </h4>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <i class="material-icons">keyboard_arrow_left</i>
                            <span class="sr-only">Previous</span>
                          </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <i class="material-icons">keyboard_arrow_right</i>
                            <span class="sr-only">Next</span>
                          </a>
                </div>
            </div>
        </div>
    </div>

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d652.0213949319333!2d-46.96023140188164!3d-22.414342345066952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8f86b1e137029%3A0x3009d44f8723f3c!2sR.+Seis+de+Dezembro+-+Vila+Santa+Luzia%2C+Mogi+Mirim+-+SP!5e0!3m2!1spt-BR!2sbr!4v1532606048512" width="1590" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>

        <div class="space-70"></div> 

<div class="main main-raised">
    
        <div class="card card-signup">
                
        <div class="card-header card-header-primary text-center">
                <h3>R.  Seis de Dezembro - Vila Santa Luzia</h3> 
                <h3>Vila Santa Luzia, Mogi Mirim - SP</h3> 
        </div>
    
    <div class="section section-contacts">
            <div class="row">
                <div class="col-md-8 ml-auto mr-auto">
                    <h2>Fale conosco...</h2>
                    <h4 class="text-center">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</h4>
                    <form action="/mensagem" method="POST" class="contact-form" >
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="bmd-label-floating"  for="contact-email">Nome...</label>
                                    <input name="nome" type="text" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="bmd-label-floating" for="contact-email">Email...</label>
                                    <input name="email" type="email" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="exampleMessage" class="bmd-label-floating"  for="contact-email">Sua mensagem...</label>
                            <textarea name="mensagem" type="text" class="form-control" rows="4" id="exampleMessage"></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-4 ml-auto mr-auto text-center">
                            <button class="btn btn-primary" type="submit">ENVIAR</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
</div>


    <div class="main main-raised">
       
    </div>
    </div>
    </div>
    <!-- 	            end nav tabs -->
    <div class="section section-white">
        <div class="container">


            <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i class="material-icons">clear</i>
                    </button>
                        </div>
                        <div class="modal-body">
                            <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there
                                live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics,
                                a large language ocean. A small river named Duden flows by their place and supplies it with
                                the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences
                                fly into your mouth. Even the all-powerful Pointing has no control about the blind texts
                                it is an almost unorthographic life One day however a small line of blind text by the name
                                of Lorem Ipsum decided to leave for the far World of Grammar.
                            </p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-link">Nice Button</button>
                            <button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    

        <div class="row bg-white">
            <div class="col-md-12">
                
<?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>