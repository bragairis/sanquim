<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>

    <div class="row">
    <div class="section section-signup page-header" style="background-image: url('/img/ws_Mountain_View_1280x720.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-md-4 ml-auto mr-auto">
            <div class="card card-signup">
              <form class="form" method="" action="">
                  <div class="card-header card-header-primary text-center">
                  <h4>Login</h4>                  
                    </a>                
                </div>                           
                <div class="card-body">
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="material-icons">face</i>
                      </span>
                    </div>
                    <input type="text" class="form-control" placeholder="Nome...">
                  </div>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="material-icons">email</i>
                      </span>
                    </div>
                    <input type="email" class="form-control" placeholder="Email...">
                  </div>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="material-icons">lock_outline</i>
                      </span>
                    </div>
                    <input type="password" class="form-control" placeholder="Senha...">
                  </div>
                  </div>
                    <div class="card-footer justify-content-center">
                        <button class="btn btn-primary btn-round">
                             Entrar
                        </button>
                    </div>
                <div class="card-footer justify-content-center">
                    <div class="cd-section">
                        <div class="title">
                                <h4>
                                    <small>Possuis conta?</small>   
                                <br>
                                    <small>Não? Então...</small>
                                    </h4>                            
                        </div>
                    </div>  
                </div>    
                    <div class="card-footer justify-content-center">    

                       <a href="/cadastro" class="btn btn-primary btn-sm">Cadastre-se</a>               
                    </div>            
                  
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
   
    
        <!-- footer -->
        <div class="space-50"></div>
    </div>
     </div>
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>