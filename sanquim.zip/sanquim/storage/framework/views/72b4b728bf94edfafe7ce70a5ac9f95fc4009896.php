<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <!-- Favicons -->
    <link rel="icon" href="/img/sanquimicone.png">
    <script src="./assets/js/jquery-3.1.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link href="/css/intro.css" rel="stylesheet">
    <script src="<?php echo e(asset('js/intro.js')); ?>"></script>
    <script src="<?php echo e(asset('js/usuario.js')); ?>"></script>
    <title>
            Sanquim
        </title>
        <!--     Fonts and icons     -->
        <link rel="stylesheet" type="text/css" href="/css/fonts.googleapis.css"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
        <link href="/css/material-kit.css?v=2.0.2" rel="stylesheet">
        <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
        <link href="/css/estilo.css" rel="stylesheet">
       
    
</head>

<body class="index-page">
    <div id="loader" class="loader"></div>
    <div class="" style="display:none;" id="page-secundaria">

    <!--menu-->
    <nav class="navbar navbar-color-on-scroll navbar-transparent    fixed-top  navbar-expand-lg " color-on-scroll="100" id="sectionsNav">
        <div class="container">
            <div class="navbar-translate">
                <a class="navbar-brand" href="/">SANQUIM </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    <span class="navbar-toggler-icon"></span>
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ml-auto">

                    <li class="nav-item">
                        <a class="nav-link" href="/professores">
                             Professores
                        </a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" href="/contato">
                             Patrocinadores
                        </a>
                    </li>  
                    <li class="nav-item">
                        <a class="nav-link" href="/contato">
                             Contato
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/">
                             Sair
                             
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>


    <?php echo $__env->yieldContent('conteudo'); ?>

     <!-- footer -->
    <div class="bg-white row">
            <div class="col-md-6 ml-auto mr-auto">
                <h3>Nossos Cursos</h3>
                <div class="list-group">
                    <a href="/prevestibular" class="list-group-item col-md-4 list-group-item-action list-group-item-light">Pré-Vestibular</a>
                    <a href="/prevestibulinho" class="list-group-item col-md-4 list-group-item-action list-group-item-light">Pré-Vestibulinho</a>
                </div>
                <ul class="list-unstyled list-inline social" >
                    <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li> 
                    <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
  
                </ul>
                
            </div>
        <div class="col-md-2 ml-auto mr-auto" >
      
            <h3>Contato</h3>
            <h5>{localizacao}</h5>
            <h5>{telefone}</h5>
            <h5>{horario}</h5>
            <button type="button" class="btn  btn-labeled btn-success" href="#" style="" data-toggle="modal" data-target="#equipe">
            Equipe
            </button>
        </div>
    </div>
    <!--/footer-->
    <div class="modal fade" id="equipe" tabindex="-1" role="dialog" aria-labelledby="equipeLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="equipeLabel">Quem produziu o site?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        LALALALLALALA EQUIPÉ LALALALAL
       
    </div>
  </div>
</div> 
</div>
    
    <!--   Core JS Files   -->
    <script src="/js/core/jquery.min.js"></script>
    <script src="/js/core/popper.min.js"></script>
    <script src="/js/bootstrap-material-design.js"></script>
    <!--  Plugin for Date Time Picker and Full Calendar Plugin  -->
    <script src="/js/plugins/moment.min.js"></script>
    <!--	Plugin for the Datepicker, full documentation here: https://github.com/Eonasdan/bootstrap-datetimepicker -->
    <script src="/js/plugins/bootstrap-datetimepicker.min.js"></script>
    <!--	Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
    <script src="/js/plugins/nouislider.min.js"></script>
    <!-- Material Kit Core initialisations of plugins and Bootstrap Material Design Library -->
    <script src="/js/material-kit.js?v=2.0.2"></script>
    <!-- Fixed Sidebar Nav - js With initialisations For Demo Purpose, Don't Include it in your project -->
    <script src="/assets-for-demo/js/material-kit-demo.js"></script>

    <script>
        $(document).ready(function () {

            //init DateTimePickers
            materialKit.initFormExtendedDatetimepickers();

            // Sliders Init
            materialKit.initSliders();
        });
    </script>
</body>

</html>