<?php $__env->startSection('conteudo'); ?>

  

<div class="row">
<div class="section section-signup page-header" style="background-image: url('/img/ws_Mountain_View_1280x720.jpg');">
<link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen"> 
        <div class="space"></div>  
          
        <div class="container">
                <div class="row user-menu-container square">
                <div class="col-md-7 user-details">
                        <div class="row coralbg white">
                            <div class="col-md-6 no-pad">
                                <div class="user-pad">
                                    <h3>Bem-Vindo, <?php echo e(Auth::user()->name); ?>!</h3>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Administrador</h4>
                                    <a  class="btn btn-lg btn-labeled btn-info" href="configuracoes" style="margin-bottom: 15px; padding: 10px;">Configurações</a>
                                </div>
                            </div>
                            <div class="col-md-6 no-pad" style="padding-right: 0px;">
                                <!-- <div class="user-image"> isso aq vai deixar num tamanho padrao, dps resolver isso-->
                                <img src="img/avatar/professores/avatar.jpg" class="img-responsive thumbnail" style="max-width: 265px;max-height: 265px;">
                                <!-- </div> -->
                            </div>
                        </div>
                        <div class="row overview" style="margin-top:10px; padding:15px;">
                                <div class=" col-md-6 ">
                                <center><a  class="btn btn-lg btn-labeled btn-info" href="#" data-toggle="modal" data-target="#deletarnoticia" style="margin-bottom: 15px;">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Excluir Notícias
                                </a></center>
                                <center><a  class="btn btn-lg btn-labeled btn-info" href="/criarnoticia" style="margin-bottom: 15px;">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Postar Notícias
                                </a></center>
                                </div>
                                <div class="col-md-6 ">
                                <center ><a  class="btn btn-lg btn-labeled btn-info" href="/msg-adm" style="margin-bottom: 15px;">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Abrir Mensagens
                                </a></center>
                               
                                <center><a  class="btn btn-lg btn-labeled btn-info" href="#"  data-toggle="modal" data-target="#deletarprof">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Deletar Professor
                                </a></center>
                                </div>
                           
                        </div>
                    </div>
                    <div class="col-md-1 user-menu-btns">
                        <div class="btn-group-vertical square" style="margin:0px;" id="responsive">
                            <a href="#" class="btn btn-block btn-default active">
                            <i class="fa fa-bell-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-clock-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-user-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-cloud-upload fa-3x"></i>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 user-menu user-pad">
                        <div class="user-menu-content active">
                        <h2 class="text-center">
                                SIMULADOS
                            </h2>
                            <h4 style="margin-top: 0px;">Para os cursos de pré-vestibular</h4>
                            <?php $__currentLoopData = $simulados_vestibular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="user-menu-list">
                                <li>
                                    <h4><i class="fa  fa-chevron-right  coral"></i><?php echo e($p->dia); ?></h4>
                                </li>
    
                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="user-menu-content">
                            <h2 class="text-center">
                                HORÁRIOS
                            </h2>
                            <h4 class="text-center">Veja o horário das aulas dessa semana!</h4>
                            <center><i class="fa fa-clock-o fa-4x"></i></center>
                            <div class="share-links">
                                <center><button type="button" class="btn btn-lg btn-labeled btn-success" href="#" style="margin-bottom: 15px;" data-toggle="modal" data-target="#horarios">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Baixar Horários
                                </button></center>
                            </div>
                        </div>
                        <div class="user-menu-content ">
                        <h2 class="text-center">
                                ALUNOS
                            </h2>
                            <h4 class="text-center">Consulte sua sala de aula!</h4>
                            <center><i class="fa fa-user-circle-o fa-4x"></i></center>
                            <div class="share-links">
                                <center><a  class="btn btn-lg btn-labeled btn-info" href="/alunosvestibular" style="margin-bottom: 15px;">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibular
                                </a></center>
                                <center><a  class="btn btn-lg btn-labeled btn-primary" href="/alunosvestibulinho" >
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibulinho
                                </a></center>
                            </div>
                        </div>
                       
                        
                        <div class="user-menu-content">
                            <h2 class="text-center">
                                MATERIAL DE APOIO
                            </h2>
                            <h4 class="text-center">Otimize seu aprendizado em casa!</h4>
                            <center><i class="fa fa-cloud-upload fa-4x"></i></center>
                            <div class="share-links">
                                <center><button type="button" class="btn btn-lg btn-labeled btn-success" href="#" style="margin-bottom: 15px;" data-toggle="modal" data-target="#vestibular">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibular
                                </button></center>
                                <center><button type="button" class="btn btn-lg btn-labeled btn-warning" href="#" data-toggle="modal" data-target="#vestibulinho">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibulinho
                                </button></center>
                            </div>
                        </div>
                    </div>
                </div> 
                <br>
                <div>
                <a  class="btn btn-lg btn-labeled btn-info" href="/editarperfil" style="margin-bottom: 15px; ">Editar Perfil</a>
                </div>
        </div>
       
        <div class="space-50"></div>

</div>

<!-- Modal -->

<!-- deletar noticias -->
<div class="modal fade" id="deletarnoticia" tabindex="-1" role="dialog" aria-labelledby="deletarprofLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="deletarprofLabel">Deletar Noticias</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <h5 style="color:#8b8b8b;">(essa ação não deletara a conta do professor)</h5>
        <ul class="user-menu-list" style="overflow-y:scroll; height: 400px;">
            <div class="mail-box">
                <aside class="lg-side">    
                    <div class="inbox-body">
                        <table class="table table-inbox table-hover">
                            <tbody> 
                            
                            <?php $__currentLoopData = $noticia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="unread"  >
                                    <td class="view-message">                                                
                                    
                                    <form action="/noticia/deletar/<?php echo e($p->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="delete" />
                                        <button rel="tooltip" class="btn btn-danger"><i class="material-icons">close</i></button>
                                         Noticia <?php echo e($p->titulo); ?>

                                    </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            
                            </tbody>
                        </table>
                    </div>
                </aside> 
            </div>
        </ul>
    </div>
  </div>
</div> 
</div>

<!-- deletar teacher -->
<div class="modal fade" id="deletarprof" tabindex="-1" role="dialog" aria-labelledby="deletarprofLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="deletarprofLabel">Deletar Professores</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <h5 style="color:#8b8b8b;">(essa ação não deletara a conta do professor)</h5>
        <ul class="user-menu-list" style="overflow-y:scroll; height: 400px;">
            <div class="mail-box">
                <aside class="lg-side">    
                    <div class="inbox-body">
                        <table class="table table-inbox table-hover">
                            <tbody> 
                            
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="unread"  >
                                    <td class="view-message">                                                
                                    
                                    <form action="/professor/deletar/<?php echo e($d->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="_method" value="delete" />
                                        <button rel="tooltip" class="btn btn-danger"><i class="material-icons">close</i></button>
                                        Professor(a)  <?php echo e($d->nome); ?>

                                    </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                            
                            </tbody>
                        </table>
                    </div>
                </aside> 
            </div>
        </ul>
    </div>
  </div>
</div> 
</div>
<!-- /deletar teacher -->

<!-- horarioss -->
<div class="modal fade" id="horarios"tabindex="-1" role="dialog" aria-labelledby="horariosLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="horariosLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

    </div>
  </div>
</div> 
</div>
<!-- /horarioss -->
<!-- material de apoio- pre vestibular -->
<div class="modal fade" id="vestibular" tabindex="-1" role="dialog" aria-labelledby="vestibularLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="vestibularLabel">Material de Apoio</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <a class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Abrir GoogleDrive: Pré-Vestibular
       </a>
    </div>
  </div>
</div> 
</div>
<!-- //material de apoio- pre vestibular -->
<!-- material de apoio- pre vestibulinho -->
<div class="modal fade" id="vestibulinho" tabindex="-1" role="dialog" aria-labelledby="vestibulinhoLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="vestibulinhoLabel">Material de Apoio</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <a class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
      Abrir GoogleDrive: Pré-Vestibulinho
       </a>
      </div>
    </div>
  </div>
</div> 
</div>
<!-- //material de apoio- pre vestibulinho -->
</div>
<script>
			$(function () { // wait for document ready
				// init controller
				var controller1 = new ScrollMagic.Controller({container: "#container1"});

			});
		</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>