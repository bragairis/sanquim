<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>

    <!--carrosel principal-->
<div class="row">
    <div class="page-header">
        <div class="card card-raised card-carousel" style="margin-top: 0px; margin-bottom: 0px;">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
               
                <div class="carousel-inner">
                    <!-- IMAGEM TEM Q TER TAMANHO DE 1366X768 OU 1280X720-->
                    <div class="carousel-item active">
                        <img class="w-100" src="/img/ws_Mountain_View_1280x720.jpg" alt="First slide">
                        
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="/img/capat.png" alt="Second slide">
                        
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="/img/bg3.jpg" alt="Third slide">
                       
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <i class="material-icons">keyboard_arrow_left</i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <i class="material-icons">keyboard_arrow_right</i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
<!--/carrosel principal-->
    

<div class="main main-raised">
    
    <div class="card card-signup">
    <div class="card-header card-header-primary text-center">
            <h3>Revista</h3> 
    </div>

<div class="section section-contacts">
        <div class="row">
            <div class="col-md-6 ml-auto mr-auto">
                <div class="card-footer justify-content-center ">
                <?php $__currentLoopData = $revista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="card-img-top"  href="<?php echo e(url("storage/pdf/revista/$p->arquivo")); ?>"><i class="fa fa-download"></i>   Download </a>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                </div>    
            </div>
            <div class=" col-sm-6 col-md-4" style="margin-right:30px;">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="scard">
                                <div class="card-body text-center">
                                <?php $__currentLoopData = $sobre_revista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><img src="<?php echo e(url("storage/img/sobre-revista/$p->foto")); ?>" /></p>
                                    <h4 class="card-title"><?php echo e($p->nome); ?></h4>
                                    <p class="card-text">Escritora</p>
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="scard ">
                     <!--inserir modal aqui fofas -->
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">REVISTA</h4>
                                    <p class="card-text"><?php echo e($p->sobre); ?></p>  
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
                              
        </div>
    </div>
    
    
    </div>

        

</div>


<div class="main main-raised">
   
</div>
</div>
</div>
<!--                end nav tabs -->
<div class="section section-white">
    <div class="container">


        <div class="modal fade" id="myModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Modal title</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="material-icons">clear</i>
                </button>
                    </div>
                    <div class="modal-body">
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there
                            live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics,
                            a large language ocean. A small river named Duden flows by their place and supplies it with
                            the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences
                            fly into your mouth. Even the all-powerful Pointing has no control about the blind texts
                            it is an almost unorthographic life One day however a small line of blind text by the name
                            of Lorem Ipsum decided to leave for the far World of Grammar.
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-link">Nice Button</button>
                        <button type="button" class="btn btn-danger btn-link" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

   <?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>