<?php $__env->startSection('conteudo'); ?>

<div class="row">
<div class="section section-signup page-header" style="background-image: url('/img/ws_Mountain_View_1280x720.jpg');">
<link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen"> 
        <div class="space"></div>  
          
        <div class="container">
                <div class="row user-menu-container square">
                <div class="col-md-7 user-details">
                        <div class="row coralbg white">
                            <div class="col-md-6 no-pad">
                                <div class="user-pad">
                                    <h3>Bem-Vindo, <?php echo e(Auth::user()->name); ?>!</h3>
                                    <?php if( Auth::user()->sala == 'Vestibular A'): ?>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibular</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma A</h4>
                                    <?php elseif(Auth::user()->sala == 'Vestibular B'): ?>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibular</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma B</h4>
                                    <?php elseif(Auth::user()->sala == 'Vestibular C'): ?>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibular</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma C</h4>
                                    <?php elseif(Auth::user()->sala == 'Vestibular D'): ?>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibular</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma D</h4>
                                    <?php elseif(Auth::user()->sala == 'Vestibulinho A'): ?>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibulinho</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma A</h4>
                                    <?php elseif(Auth::user()->sala == 'Vestibulinho B'): ?>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibulinho</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma B</h4>
                                    <?php elseif(Auth::user()->sala == 'Vestibulinho C'): ?>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibulinho</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma C</h4>
                                    <?php elseif(Auth::user()->sala == 'Vestibulinho D'): ?>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibulinho</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma D</h4>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6 no-pad" style="padding-right: 0px;">
                                <!-- <div class="user-image"> isso aq vai deixar num tamanho padrao, dps resolver isso-->
                                <?php $imagem = Auth::user()->imagem;  ?>
                                <?php if($imagem == ''): ?>
                                <img src="img/user.png" class="img-responsive thumbnail" style="max-width: 265px;max-height: 265px;">
                                <!-- </div> -->
                                <?php else: ?>
                                <img src="<?php echo e(url("storage/img/perfil/$imagem")); ?>" alt="Perfil" style="min-width: 260px;max-width: 265px;max-height: 265px;min-height: 260px;"/>
                                <?php endif; ?>                                <!-- </div> -->
                            </div>
                        </div>
                        <div class="row overview" style="padding-bottom:20px; padding-top:10px;">
                         
                            <div class="col-md-12 text-center" style="color:#ff0a00;">
                               <h3> Educação não transforma o mundo. Educação muda as pessoas. As pessoas mudam o mundo - Paulo Freirre </h3>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1 user-menu-btns" >
                    <div class="btn-group-vertical square" style="margin:0px;" id="responsive">
                            <a href="#" class="btn btn-block btn-default active">
                            <i class="fa fa-bell-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-clock-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-user-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-cloud-upload fa-3x"></i>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 user-menu user-pad">
                        <div class="user-menu-content active">
                        <?php if( Auth::user()->sala == 'Vestibular A' && 'Vestibular B' && 'Vestibular C' && 'Vestibular D' ): ?>
                        <h2 class="text-center" style="margin-bottom: 0px;">
                                SIMULADOS
                            </h2>
                            <?php $__currentLoopData = $simulados_vestibular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="user-menu-list">
                                <li>
                                    <h4><i class="fa  fa-chevron-right  coral"></i><?php echo e($p->dia); ?></h4>
                                </li>
    
                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <h2 class="text-center" style="margin-bottom: 0px;">
                                SIMULADOS
                            </h2>
                            <?php $__currentLoopData = $simulados_vestibulinho; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="user-menu-list">
                                <li>
                                    <h4><i class="fa  fa-chevron-right  coral"></i> <?php echo e($p->dia); ?></h4>
                                </li>
                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </div>
                        <div class="user-menu-content">
                            <h2 class="text-center">
                                HORÁRIOS
                            </h2>
                            <h4 class="text-center">Veja o horário das aulas dessa semana!</h4>
                            <center><i class="fa fa-cloud-upload fa-4x"></i></center>
                            <div class="share-links">
                                <center><button type="button" class="btn btn-lg btn-labeled btn-primary" href="#" style="margin-bottom: 15px;" data-toggle="modal" data-target="#horarios">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Baixar Horários
                                </button></center>
                            </div>
                        </div>
                        <div class="scroll user-menu-content">
                        <h2 class="text-center">
                                PROFESSORES
                            </h2>
                            
                            <ul class="user-menu-list" style="overflow-y:scroll;     height: 240px;">
                            <!-- professor https://bootsnipp.com/snippets/featured/responsive-navigation-menu-->
                            <?php $__currentLoopData = $professores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <h4><?php echo e($p->nome); ?><small class="coral"><?php echo e($p->materia); ?> </small><a href="#"><i class="fa fa-plus-circle " data-toggle="collapse" data-target="#<?php echo e($p->id); ?>" class="collapsed active"></i></a></h4>
                                    <ul class="sub-menu collapse" id="<?php echo e($p->id); ?>">
                                    <h5><?php echo e($p->email); ?></h5>
                                    </ul>
                                </li> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <!-- /professor -->
                        </div>
                       
                        
                        <div class="user-menu-content">
                            <h2 class="text-center">
                                MATERIAL DE APOIO
                            </h2>
                            <h4 class="text-center">Otimize seu aprendizado em casa!</h4>
                            <center><i class="fa fa-cloud-upload fa-4x"></i></center>
                            <div class="share-links">
                                <center><button type="button" class="btn btn-lg btn-labeled btn-success" href="#" style="margin-bottom: 15px;" data-toggle="modal" data-target="#vestibular">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibular
                                </button></center>
                                <center><button type="button" class="btn btn-lg btn-labeled btn-warning" href="#" data-toggle="modal" data-target="#vestibulinho">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibulinho
                                </button></center>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div>
                <a  class="btn btn-lg btn-labeled btn-success" href="/editarperfil" style="margin-bottom: 15px; ">Editar Perfil</a>
                </div>
        </div>
        <div class="space-50"></div>

</div>



<!-- Modal -->



    

<!-- horarioss -->
<div class="modal fade" id="horarios"tabindex="-1" role="dialog" aria-labelledby="horariosLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="horariosLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-5">
      <div class="card ">
            <div class="card-body ">
            <div class="news-title">
            <img src="img/pdf.png" class="img-responsive thumbnail " style="width:85px; height: 85px;">   
            <h3 class=" title-small text-center"><a href="<?php echo e(url("storage/pdf/horarios/$p->arquivo")); ?>" target="_blank">Ver Horários</a></h3>            
            </div>
        </div>
      </div> 
      </div>              
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div> 
</div>
<!-- /horarioss -->


<!-- material de apoio- pre vestibular -->
<div class="modal fade" id="vestibular" tabindex="-1" role="dialog" aria-labelledby="vestibularLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="vestibularLabel">Material de Apoio</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <a class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Abrir GoogleDrive: Pré-Vestibular
       </a>
    </div>
  </div>
</div> 
</div>
<!-- //material de apoio- pre vestibular -->
<!-- material de apoio- pre vestibulinho -->
<div class="modal fade" id="vestibulinho" tabindex="-1" role="dialog" aria-labelledby="vestibulinhoLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="vestibulinhoLabel">Material de Apoio</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <a class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
      Abrir GoogleDrive: Pré-Vestibulinho
       </a>
      </div>
    </div>
  </div>
</div> 
</div>
</div>
<script>
			$(function () { // wait for document ready
				// init controller
				var controller1 = new ScrollMagic.Controller({container: "#container1"});

			});
		</script>
<?php $__env->stopSection(); ?>

            
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>