<?php $__env->startSection('conteudo'); ?>

  

<div class="row">
<div class="section section-signup page-header" style="background-image: url('/img/ws_Mountain_View_1280x720.jpg');">
<link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen"> 
        <div class="space"></div>  
          
            <div class="container">
                <div class="row user-menu-container square">
                    <div class="col-md-7 user-details">
                        <div class="row coralbg white">
                            <div class="col-md-6 no-pad">
                                <div class="user-pad">
                                    <h3>Bem-Vindo, Marcos!</h3>
                                    <h4 class="white text-left"><i class="fa fa-graduation-cap"></i> Curso Pré-Vestibular</h4>
                                    <h4 class="white text-left"><i class="fa fa-id-card"></i>    Turma A</h4>
                                    
                                </div>
                            </div>
                            <div class="col-md-6 no-pad">
                                <!-- <div class="user-image"> isso aq vai deixar num tamanho padrao, dps resolver isso-->
                                    <img src="/img/kit/faces/marc.jpg" class="img-responsive thumbnail">
                                <!-- </div> -->
                            </div>
                        </div>
                        <div class="row overview">
                            <div class="col-md-4 user-pad text-center">
                                
                                <div class="share-links">
                                <button type="button" class="btn btn-lg btn-labeled btn-success" href="#" style="margin-bottom: 15px;" data-toggle="modal" data-target="#downloads">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Horários
                                </button>
                                </div> 
                            </div>
                            <div class="col-md-4 user-pad text-center">
                                <h3>FOLLOWING</h3>
                                <h4>456</h4>
                            </div>
                            <div class="col-md-4 user-pad text-center">
                                <h3>APPRECIATIONS</h3>
                                <h4>4,901</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1 user-menu-btns">
                        <div class="btn-group-vertical square" id="responsive">
                            <a href="#" class="btn btn-block btn-default active">
                            <i class="fa fa-bell-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-envelope-o fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-laptop fa-3x"></i>
                            </a>
                            <a href="#" class="btn btn-default">
                            <i class="fa fa-cloud-upload fa-3x"></i>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 user-menu user-pad">
                        <div class="user-menu-content active">
                            <h3>
                                Simulados
                            </h3>
                            <ul class="user-menu-list">
                                <li>
                                    <h4><i class="fa  fa-chevron-right  coral"></i> 23/06/2018</h4>
                                </li>
                                <li>
                                    <h4><i class="fa fa-chevron-right coral"></i> 23/06/2018</h4>
                                </li>
                                <li>
                                    <h4><i class="fa fa-chevron-right coral"></i> 23/06/2018</h4>
                                </li>
                                <li>
                                    <h4><i class="fa fa-chevron-right coral"></i> 23/06/2018</h4>
                                </li>
                                
                            </ul>
                        </div>
                        <div class="user-menu-content">
                            <h3>
                                Caixa de Mensagem
                            </h3>
                            <ul class="user-menu-list">
                            <div class="mail-box">
                                <aside class="lg-side">    
                                    <div class="inbox-body">
                                        <table class="table table-inbox table-hover">
                                            <tbody>
                                            <tr class="unread"  data-toggle="modal" data-target="#exampleModal">
                                               <td class="view-message  dont-show">
                                               Carlinhos</td>
                                                <td class="view-message ">Bora fecha o tcc</td>
                                            </tr>
                                            <tr class="unread"  data-toggle="modal" data-target="#exampleModal">
                                                <td class="view-message  dont-show">Antonieto</td>
                                                <td class="view-message ">Suave mermão bora cola la em casa</td>
                                                
                                            </tr>
                                            <tr class="unread"  data-toggle="modal" data-target="#exampleModal">
                                                <td class="view-message  dont-show">Iris</td>
                                                <td class="view-message ">Letra maiuscula é bonita</td>
                                                
                                            </tr>
                                            
                                        </tbody>
                                        </table>
                                    </div>
                                </aside>
                                </div>
                            </ul>
                        </div>
                        <div class="scroll user-menu-content">
                            <h3>
                                Professores
                            </h3>
                           
                            <ul class="user-menu-list">
                            <!-- professor https://bootsnipp.com/snippets/featured/responsive-navigation-menu-->
                            <li>
                            <h4>Rogerinho <small class="coral">Biologia </small><a href="#"><i class="fa fa-plus-circle " data-toggle="collapse" data-target="#prof1" class="collapsed active"></i></a></h4>
                            <ul class="sub-menu collapse" id="prof1">
                            <h5>rogerinho@gmail.com</h5>
                            </ul>
                            </li> 
                            <!-- /professor -->
                            
                            <!-- professor -->
                            <li>
                            <h4>Celson <small class="coral">Biologia </small><a href="#"><i class="fa fa-plus-circle " data-toggle="collapse" data-target="#prof2" class="collapsed active"></i></a></h4>
                            <ul class="sub-menu collapse" id="prof2">
                            <h5>celsinho@gmail.com</h5>
                            </ul>
                            </li> 
                            <!-- /professor -->
                            
                            <!-- professor -->
                            <li>
                            <h4>Milton <small class="coral">Biologia </small><a href="#"><i class="fa fa-plus-circle " data-toggle="collapse" data-target="#prof3" class="collapsed active"></i></a></h4>
                            <ul class="sub-menu collapse" id="prof3">
                            <h5>miltinhosz2@gmail.com</h5>
                            </ul>
                            </li> 
                            <!-- /professor -->
                            
                            <!-- professor -->
                            <li>
                            <h4>Zureide <small class="coral">Biologia </small><a href="#"><i class="fa fa-plus-circle " data-toggle="collapse" data-target="#prof4" class="collapsed"></i></a></h4>
                            <ul class="sub-menu collapse" id="prof4">
                            <h5>maedotavares@gmail.com</h5>
                            </ul>
                            </li> 
                            <!-- /professor --> 
                            </ul>
                                      
                        </div>
                       
                        
                        <div class="user-menu-content">
                            <h2 class="text-center">
                                MATERIAL DE APOIO
                            </h2>
                            <h4 class="text-center">Otimize seu aprendizado em casa!</h4>
                            <center><i class="fa fa-cloud-upload fa-4x"></i></center>
                            <div class="share-links">
                                <center><button type="button" class="btn btn-lg btn-labeled btn-success" href="#" style="margin-bottom: 15px;" data-toggle="modal" data-target="#downloads">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibular
                                </button></center>
                                <center><button type="button" class="btn btn-lg btn-labeled btn-warning" href="#" data-toggle="modal" data-target="#exampleModal">
                                        <span class="btn-label"><i class="fa fa-bell-o"></i></span>Pré-Vestibulinho
                                </button></center>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="space-50"></div>

</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Material de apoio: Pré-Vestibulinho
       </button>
    </div>
  </div>
</div> 
</div>

<div class="modal fade" id="downloads" tabindex="-1" role="dialog" aria-labelledby="downloadsLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="downloadsLabel">Material de Apoio</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Material de apoio: Pré-Vestibular 
       </button>
      </div>
    </div>
  </div>
</div> 
</div>

<script>
			$(function () { // wait for document ready
				// init controller
				var controller1 = new ScrollMagic.Controller({container: "#container1"});

			});
		</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.principallogado', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>