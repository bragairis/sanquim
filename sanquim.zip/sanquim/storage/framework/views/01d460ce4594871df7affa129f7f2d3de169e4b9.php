<?php $__env->startSection('conteudo'); ?>

<div class="row">
<div class="section section-signup page-header" style="background-image: url('/img/capalogin.png');">
<link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen"> 

      
            <div class="space-30 container card card-signup ">
            
                    
                    <div class="card-header card-header-primary text-center">
                        <h4>Configurações</h4>                  
                        </a>                
                    </div>
                <div class="row user-menu-container square">
                    
                    <div class="col-md-3 user-menu-btns">
                        <div class="btn-group-vertical square" id="responsive">
                            <a href="#" class="btn btn-block btn-default active">
                              Pagina Inicial
                            </a>
                            <a href="#" class="btn btn-default">
                            Professores
                            </a>
                            <a href="#" class="btn btn-default">
                             Alunos
                            </a>
                            <a href="#" class="btn btn-default">
                             Definições
                            </a>
                            <a href="#" class="btn btn-default">
                             Contato
                            </a>
                            <a href="#" class="btn btn-default">
                             Revista
                            </a>
                            <a href="#" class="btn btn-default">
                             Area do Aluno
                            </a>
                        </div>
                    </div>
                    <div class="col-md-9 user-menu user-pad">
                        <div class="user-menu-content active">
                          <h2 > Administre a página inicial </h2>
                            <table class="table table-striped">
                                <tbody>
                                  <tr>
                                    <td colspan="1">
                                      <h4 > Adicionar Ex-Alunos Destaque </h4> 
                   
                                          <form class="well" action="/teste" method="POST" enctype="multipart/form-data" >
                                           <?php echo csrf_field(); ?>
                                              <fieldset>
                                                  <div class="container">
                                                    <div class="row">
                                                      <div class="form-group col-md-4">
                                                          <label class="control-label">Nome </label>
                                                          <div class="inputGroupContainer">
                                                            <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="fullName" name="nome" class="form-control" required="true" value="" type="text"></div>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-2">
                                                          <label class="control-label">Universidade</label>
                                                          <div class="inputGroupContainer">
                                                            <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine1" name="faculdade"  class="form-control" required="true" value="" type="text"></div>
                                                          </div>
                                                      </div>
                                                      <div class="form-group col-md-4">
                                                          <label class="control-label">Mensagem</label>
                                                          <div class="inputGroupContainer">
                                                            <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine2" name="mensagem"  class="form-control" required="true" value="" type="text"></div>
                                                          </div>
                                                      </div>
                                                      <div class="col-md-6 ">
                                                            <label class="control-label">Foto</label>
                                                            <br>
                                                            <input type="file" name="foto">
                                                      </div>
                                                      <div class="">
                                                          <button class="btn btn-info btn-round" type="submit">
                                                            Adicionar
                                                          </button>
                                                      </div>
                                                    </div>
                                                  </div>
                                              </fieldset>
                                          </form>

                                    </td>
                                  </tr>
                                </tbody>
                            </table>
                            <!-- aaaaa -->
                            
                            <div class="container">
                              <div class="row ">
                                <form class="well" action="/imgRevista/{id}" method="POST" enctype="multipart/form-data" >
                                <?php echo e(csrf_field()); ?> 
                                  <h4 > Alterar Imagem da Pagina da Revista </h4>
                                    <div class="col-md-4">
                                      <input type="file" name="image">
                                    </div>
                                    <br>
                                    <div class="">
                                      <button class="btn btn-info btn-round">
                                          Adicionar
                                      </button>
                                    </div>
                                </form>
                                <form class="well" action="/teste" method="POST"><?php echo csrf_field(); ?>
                                  <h4 > Alterar Imagens do Carrosel </H4>
                                  <div class="col-md-4">
                                    <input type="file" name="image">
                                  </div>
                                  <INPUT TYPE="RADIO" NAME="OPCAO" VALUE="carr1"> Foto 1     
                                  <INPUT TYPE="RADIO" NAME="OPCAO" VALUE="carr2"> Foto 2 
                                  <INPUT TYPE="RADIO" NAME="OPCAO" VALUE="carr3"> Foto 3 
                                  <div class="">
                                      <button class="btn btn-info btn-round">
                                          Adicionar
                                      </button>
                                      </div>
                                </form>
                              </div>
                            </div>
                        </div>
                        <div class="user-menu-content">
                          <div class="container">
                            <table class="table table-striped">
                                <tbody>
                                  <tr>
                                      <td colspan="1">
                                        <h2 > Adicionar Professor </h2>
                                        <form class="well" action="/teste" method="POST" ><?php echo csrf_field(); ?>
                                            <fieldset>
                                            <div class="container">
                                            <div class="row">
                                              <div class="form-group col-md-4">
                                              
                                                  <label class="control-label">Nome Completo</label>
                                            
                                                  <div class="inputGroupContainer">
                                                    <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="fullName" name="fullName" class="form-control" required="true" value="" type="text"></div>
                                                  </div>
                                              </div>
                                              <div class="form-group col-md-4">
                                                  <label class="control-label">Disciplina</label>
                                                  <div class="inputGroupContainer">
                                                    <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine1" name="addressLine1"  class="form-control" required="true" value="" type="text"></div>
                                                  </div>
                                              </div>
                                            
                                              <div class="form-group col-md-4">
                                                  <label class="control-label">Descrição</label>
                                                  <div class="inputGroupContainer">
                                                    <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine2" name="addressLine2"  class="form-control" required="true" value="" type="text"></div>
                                                  </div>
                                              </div>
                                              <div class="form-group col-md-4 ">
                                                  <label class="control-label">Email</label>
                                                  <div class="inputGroupContainer">
                                                    <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="city" name="city"  class="form-control" required="true" value="" type="text"></div>
                                                  </div>
                                              </div>
                                              <div class="form-group col-md-4 ">  
                                                  <input type="file" name="imagem">
                                                  
                                              </div>
                                              </div>
                                            </div>
                                            </fieldset>
                                            <div class="card-footer justify-content-center">
                                              <button class="btn btn-primary btn-round">
                                                  Adicionar
                                              </button>
                                          </div>
                                        </form>
                                      </td>
                                    
                                  </tr>

                                </tbody>
                            </table>
                        </div>
                      </div>
                        <div class="scroll user-menu-content">
                            <h2 > Banco de Dados dos Alunos </h2>
                            <h4> Adicione, Delete e Verifique a conta dos Alunos!</h4>
                              <div class="container">
                                  <button class="btn btn-primary btn-round">
                                      Pré-Vestibular
                                  </button>
                                  <button class="btn btn-primary btn-round">
                                      Pré-Vestibulinho
                                  </button>
                              </div>
                        </div>

                        <div class="user-menu-content">
                            <h2 > Definições </h2>
                            <h4> Adicione ou delete as definições do site!</h4>
                          <div class="container">
                                <div class="row">
                             
                                <div class="form-group col-md-6">
                                 <form action="/defhome_edita/{id}" method="POST" class="contact-form" >
                              <?php echo e(csrf_field()); ?> 
                                  <label class="control-label"> Def. Sanquim (Pagina Principal)</label>
                                  <textarea name="definicao" class="form-control" rows="5" id="comment"><?php echo e($defhome->definicao); ?></textarea>
                                  <div>
                                  <button class="btn btn-info btn-round" type="submit">
                                          Adicionar
                                  </button>
                                  </div> 
                              </form>
                             </div>

                                <div class="form-group col-md-6">
                                <form action="/defsanquim_edita/{id}" method="POST" class="contact-form">
                                <?php echo e(csrf_field()); ?> 
                                  <label class="control-label">Def. Sanquim</label>
                                  <textarea name="sanquim" class="form-control" rows="5" id="comment"><?php echo e($defsanquim->definicao); ?></textarea>
                                  <div>
                                  <button class="btn btn-info btn-round" type="submit">
                                          Adicionar
                                  </button>
                                  </div> 
                                </form>
                                </div>  
                            </div>

                            <div class="row">
                            <div class="form-group col-md-6">  
                              <form action="/teste" method="POST" class="contact-form"><?php echo csrf_field(); ?> 
                                  <label class="control-label"> Def. Curso Pré-Vestibular</label>
                                  <textarea name="pre-vestibular" class="form-control" rows="5" id="comment"></textarea>
                                  <div>
                                  <button class="btn btn-info btn-round" type="submit">
                                          Adicionar
                                  </button>
                                  </div>
                              </form>
                               </div>

                               <div class="form-group col-md-6">
                              <form action="/teste" method="POST" class="contact-form"><?php echo csrf_field(); ?>                                
                                  <label class="control-label"> Def. Curso Pré-Vestibuliho</label>
                                  <textarea name="pre-vestibulinho" class="form-control" rows="5" id="comment"></textarea>
                                <div>
                                  <button class="btn btn-info btn-round" type="submit">
                                          Adicionar
                                  </button>
                                </div> 
                              </form>
                               </div>
                          </div>                                   
                          </div>
                          </div>

                      <div class="user-menu-content">
                      <h2 > Contato </h2>
                      <div class="container">
                      <form action="/footeredita/{id}" method="POST" class="contact-form">
                      <?php echo e(csrf_field()); ?>

                              <div class="row">
                                <div class="form-group col-md-6">
                                  <label class="control-label">Localização</label>
                                  <textarea name="localizacao" class="form-control"  rows="2" id="comment" ><?php echo e($footer->localizacao); ?></textarea> 
                                </div> 
                                <div class="form-group col-md-6">
                                  <label class="control-label">Horário de Funcionamento</label>
                                  <textarea name="horario" class="form-control" rows="1" id="comment"><?php echo e($footer->horario); ?></textarea>
                                </div>
                                <div class="form-group col-md-6">
                                  <label class="control-label">Telefone</label>
                                  <textarea name="telefone" class="form-control" rows="1" id="comment"><?php echo e($footer->telefone); ?></textarea>
                                </div>
                                <div class="form-group col-md-6">
                                  <label class="control-label">Link(Facebook)</label>
                                  <textarea name="facebook" class="form-control" rows="1" id="comment"><?php echo e($footer->facebook); ?></textarea>
                                </div>
                                <div class="form-group col-md-6">
                                  <label class="control-label">Link(Instagram)</label>
                                  <textarea name="instagram" class="form-control" rows="1" id="comment"><?php echo e($footer->instagram); ?></textarea>
                                </div>
                              <div>
                                <button class="btn btn-info btn-round" type="submit">
                                Adicionar
                                </button>
                              </div>
                      </form>
                                </div>
                              </div>
                            </div>
                      <div class="user-menu-content">
                      <h2> Alterar Imagem da Pagina da Revista </h2>
                      <form class="well " action="/teste" method="POST" enctype="multipart/form-data" ><?php echo csrf_field(); ?>
                              <h4> Upar Revista </h4>
                                    <div class="col-md-4">
                                      <input type="file" name="image">
                                    </div>
                                    <br>
                                    <button class="btn btn-info btn-round">
                                          Adicionar
                                      </button>
                        </form>
                        <form action="/teste" method="POST"><?php echo csrf_field(); ?>
                        
                                    <div class="form-group col-md-6">
                                    <h4> Sobre a escritora </h4>
                                  <textarea class="form-control" rows="5" id="comment"></textarea>
                                  <button class="btn btn-info btn-round">
                                          Adicionar
                                      </button>
                                </div>
                        </form>
                      </div>
                      <div class="user-menu-content">
                      <h2> Area do Aluno</h2>
                      <form action="/teste" method="POST"><?php echo csrf_field(); ?>
                      <h4>Simulados </h4>
                      <div class=" col-md-6">
                                                  <div class="inputGroupContainer">
                                                    <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine2" name="addressLine2"  class="form-control" required="true" value="" type="text"></div>
                                                  </div>
                                                  <button class="btn btn-info btn-round">
                                          Adicionar
                                      </button>
                                      </div>
                      </form>
                      <form class="well " action="/teste" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
                      <h4>Horarios (pdf)</h4>
                                    <div class="col-md-4">
                                      <input type="file" name="image">
                                    </div>
                                    <br>
                                    <button class="btn btn-info btn-round">
                                          Adicionar
                                      </button>
                        </form>
                      </div>
                    </div>
                </div>
        </div>
        <div class="space-50"></div>

</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Material de apoio: Pré-Vestibulinho
       </button>
    </div>
  </div>
</div> 
</div>

<div class="modal fade" id="downloads" tabindex="-1" role="dialog" aria-labelledby="downloadsLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="downloadsLabel">Material de Apoio</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Material de apoio: Pré-Vestibular 
       </button>
      </div>
    </div>
  </div>
</div> 
</div>
</div>
<script>
			$(function () { // wait for document ready
				// init controller
				var controller1 = new ScrollMagic.Controller({container: "#container1"});

			});
		</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>