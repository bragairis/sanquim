<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>

        <!--carrosel principal-->
        <<div class="row">
    <div class="page-header">
        <div class="card card-raised card-carousel" style="margin-top: 0px; margin-bottom: 0px;">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <!-- IMAGEM TEM Q TER TAMANHO DE 1366X768 OU 1280X720-->
                    <?php $__currentLoopData = $carrossel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item active">
                        <img class="w-100"  src="<?php echo e(url("storage/img/carrossel/$p->foto1")); ?>" alt="First slide">
                      
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="<?php echo e(url("storage/img/carrossel/$p->foto2")); ?>" alt="Second slide">
                       
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="<?php echo e(url("storage/img/carrossel/$p->foto3")); ?>" alt="Third slide">
                        
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <i class="material-icons">keyboard_arrow_left</i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <i class="material-icons">keyboard_arrow_right</i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
        <!--/carrosel principal-->

        <div class="main main-raised ">
            <section class="banner-sec" style="padding:30px;">
                <div class="container">
                    <div class="row ">
                            <?php $__currentLoopData = $noticia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class=" col-md-4" style="    margin-top: 60px;">
                            <img class="card-img-top"  src="<?php echo e(url("storage/img/noticia/$p->imagem")); ?>" href="/mostranoticia/<?php echo e($p->id); ?>">
                            <div class="card-body">
                                <h4 class="card-title"><?php echo e($p->titulo); ?></h4>          
                                <p class="card-text"><?php echo e($p->subtitulo); ?></p>                                    
                                <div class="card-footer justify-content-center">    
                                <a href="/mostranoticia/<?php echo e($p->id); ?>" class="btn btn-primary btn-round">Abrir</a>               
                                </div>               
                            </div>
                        </div>
                        
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                    </div>
                </div>                           
            </section>
        
        </div>



        <div class="space-50"></div>

        <!-- footer -->
        <?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>