<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>

 <div style="background-color:#033288;">   
 
      <div class="container">
      <div class="space-50"></div>
        <div class="row">
          <div class="col-md-8 ml-auto mr-auto col-146">
            <div class="card card-signup">
                  <div class="card-header card-header-primary text-center">
                  <h4>Criação de Noticias</h4>                  
                    </a>                
                </div>
                <form class="form" method="post" action="/adicionarnoticia" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>                           
                <div class="card-body">
                        <div class="form-group">
                          <label class="bmd-label-floating"  for="contact-email">Titulo da Noticia</label>
                          <input name="titulo" type="text" class="form-control">
                          </div>

                        <div class="form-group">
                          <label class="bmd-label-floating"  for="contact-email">Subtítulo</label>
                          <input name="subtitulo" type="text" class="form-control"> 
                         </div>
                          
                         <div class="form-group">
                            <label for="exampleMessage" class="bmd-label-floating"  for="contact-email">Notícia</label>
                            <textarea name="noticia" type="text" class="form-control" rows="4" id="exampleMessage"></textarea>
                        </div>
                        
                        <div>
                            <span class="fileinput-new">Adicionar Foto</span>
                        <input type="file" name="imagem" id="input-file-now" class="dropify" >        
                    </div>
                    <div class="row">
                            <div class="col-md-4 ml-auto mr-auto text-center">
                            <button class="btn btn-primary" type="submit">ENVIAR</button>
                            </div>
                        </div>
                     </div>
                      </form>       
                            
            </div>
          </div>
        </div>
      </div>
   
          
    <!--  End Modal -->
     <?php $__env->stopSection(); ?>
</body>

</html>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>