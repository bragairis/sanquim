<!DOCTYPE html>
<html lang="en">


<?php $__env->startSection('conteudo'); ?>

    <!--carrosel principal-->
    <div class="row">
        <div class="page-header">
            <div class="card card-raised card-carousel">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class=""></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item">
                            <img class="w-100" src="/img/bg3.jpg" alt="First slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Yellowstone National Park, United States
                                </h4>
                            </div>
                        </div>
                        <div class="carousel-item active">
                            <img class="w-100" src="/img/bg.jpg" alt="Second slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Somewhere Beyond, United States
                                </h4>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <img class="w-100" src="/img/bg2.jpg" alt="Third slide">
                            <div class="carousel-caption d-none d-md-block">
                                <h4>
                                    <i class="material-icons">location_on</i> Yellowstone National Park, United States
                                </h4>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                            <i class="material-icons">keyboard_arrow_left</i>
                            <span class="sr-only">Previous</span>
                          </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                            <i class="material-icons">keyboard_arrow_right</i>
                            <span class="sr-only">Next</span>
                          </a>
                </div>
            </div>
        </div>
    </div>
    <!--/carrosel principal-->
    
    <div class="main main-raised ">
        <div class="section">  
            <section class="banner-sec">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card "> <img class="img-fluid" src="http://grafreez.com/wp-content/temp_demos/river/img/politics.jpg" alt="">
                                    <div class="card-img-overlay"> <span class="badge badge-pill badge-danger">FUVEST</span> </div>
                                    <div class="card-body ">
                                <div class="news-title">
                                        <h3 class=" title-small"><a href="https://www.facebook.com" target="_blank">Syria war: Why the battle for Aleppo matters</a></h3>
                                </div>
                                    </div>
                            </div>
                            <div class="card"> <img class="img-fluid" src="http://grafreez.com/wp-content/temp_demos/river/img/travel.jpg" alt="">
                                    <div class="card-img-overlay"> <span class="badge badge-pill badge-danger">FUVEST</span> </div>
                                    <div class="card-body">
                                <div class="news-title">
                                        <h3 class=" title-small"><a href="#" target="_blank">Key Republicans sign letter warning against</a></h3>
                                </div>
                                    </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card"> <img class="img-fluid" src="http://grafreez.com/wp-content/temp_demos/river/img/business1.jpg" alt="">
                                    <div class="card-img-overlay"> <span class="badge badge-pill badge-danger">UNESP</span> </div>
                                    <div class="card-body">
                                <div class="news-title">
                                        <h3 class=" title-small"><a href="#" target="_blank">Obamacare Appears to Be Making People Healthier</a></h3>
                                </div>
                                    </div>
                            </div>
                            <div class="card"> <img class="img-fluid" src="http://grafreez.com/wp-content/temp_demos/river/img/food.jpg" alt="">
                                    <div class="card-img-overlay"> <span class="badge badge-pill badge-danger">ENEM</span> </div>
                                    <div class="card-body">
                                <div class="news-title">
                                        <h3 class=" title-small"><a href="#" target="_blank">‘S.N.L.’ to Lose Two Longtime Cast Members</a></h3>
                                </div>
                                    </div>
                            </div>
                        </div>
                        <div class="col-md-6 top-slider outrocard">
                            <div class="news-block">
                                <div class="news-media"><img class="img-fluid" src="http://grafreez.com/wp-content/temp_demos/river/img/politics1.jpg" alt=""></div>
                                <div class="news-title">
                                    <h2 class=" title-large" style="text-align:center;"><a href="#" target="_blank">Conheça nossa revista</a></h2>
                                </div>
                                <div class="news-des">Condimentum ultrices mi est a arcu at cum a elementum per cum turpis dui vulputate vestibulum in vehicula montes vel. Mauris nam suspendisse consectetur mus...</div>  
                            </div>
                        </div>
                    </div>
                </div>
            </section>
           
 
        <!--ARRUMAR ISSO NO FUTURO === AS IMAGEM N TA RESPONSIVA-->
        <div class="cinza carousel">
                    <div class=" container  text-center my-3 ssection"> 
                    
                        <div id="recipeCarousel" class="carousel slide w-100" data-ride="carousel">
                        <?php $__currentLoopData = $alunoscarrossel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-inner w-100" role="listbox">
                          
                                <div class="carousel-item row no-gutters active wall">
                                    <div class="col-2 float-left">
                                    <img class="rounded-circle" style="height: 100px; width: 100px;" src="/img/avatar/<?php echo e($p->foto); ?>">
                                    </div>
                                    <div class="col-4 float-left"><p> <?php echo e($p->mensagem); ?></p>
                                    <small><?php echo e($p->nome); ?>  -- <?php echo e($p->faculdade); ?></small>
                                    </div>

                                   <div class="col-2 float-left">
                                   <img class="rounded-circle" style="height: 100px; width: 100px;" src="/img/avatar/<?php echo e($p->foto); ?>">
                                   </div>
                                    <div class="col-4 float-left"><p> <?php echo e($p->mensagem); ?></p>
                                    <small><?php echo e($p->nome); ?>  -- <?php echo e($p->faculdade); ?></small>
                                    </div> 
                                </div>
                                <div class="carousel-item row no-gutters wall">
                                    <div class="col-2 float-left">
                                        <img class="rounded-circle" style="height: 100px; width: 100px;" src="/img/avatar/<?php echo e($p->foto); ?>">
                                        </div>
                                        <div class="col-4 float-left"><p> <?php echo e($p->mensagem); ?></p>
                                        <small><?php echo e($p->nome); ?>  -- <?php echo e($p->faculdade); ?></small>
                                        </div>

                                    <div class="col-2 float-left">
                                    <img class="rounded-circle" style="height: 100px; width: 100px;" src="/img/avatar/<?php echo e($p->foto); ?>">
                                    </div>
                                        <div class="col-4 float-left"><p> <?php echo e($p->mensagem); ?></p>
                                        <small><?php echo e($p->nome); ?>  -- <?php echo e($p->faculdade); ?></small>
                                        </div> 
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                         
                    </div>
                    <a class="carousel-control-prev" href="#recipeCarousel" role="button" data-slide="prev">
                        <i class="material-icons">keyboard_arrow_left</i>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#recipeCarousel" role="button" data-slide="next">
                        <i class="material-icons">keyboard_arrow_right</i>
                        <span class="sr-only">Next</span>
                    </a>
        </div>
 
    
 
            <div class="container">
                <div class="row text-center">
                    <div class="col-md-8 ml-auto mr-auto">
                        <h2>O que é o Sanquim?</h2>
                        <h4>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean tempor at purus porttitor elementum. Pellentesque nec leo vel ligula pulvinar varius sit amet eu justo. Aenean vitae imperdiet dolor. Nulla nec arcu sit amet erat euismod bibendum in non ipsum. Sed ut ipsum viverra, consectetur diam nec, sagittis ligula. Cras suscipit lectus ante, euismod aliquet ante facilisis eu. Quisque pulvinar diam ac libero imperdiet bibendum. Nulla aliquam nulla at nisi pellentesque, quis volutpat ex cursus. Mauris id vehicula turpis. Vestibulum ut rhoncus ante. Curabitur ullamcorper nunc a lorem fringilla, ac convallis ipsum eleifend.
                            Sed malesuada rutrum eros, ac vehicula orci interdum eget. Pellentesque accumsan ut odio a ultricies. Nam varius tempor orci vitae convallis. Ut quis efficitur mauris, nec tincidunt orci. Nam eu lobortis mi, sed luctus nulla. Maecenas mi ligula, maximus sed auctor volutpat, dapibus eu ipsum. Morbi pellentesque eu est vel sodales. Pellentesque non vulputate urna, ut dictum purus. Aliquam sed blandit lacus. Integer gravida quis leo id fringilla. Curabitur eu justo sit amet quam molestie blandit. Mauris placerat pulvinar risus, eu tempor sapien.
                        </h4>
                         <a href="/defsanquim" class="btn btn-primary btn-lg">Saiba mais</a>
                    </div>
    	        </div>
            </div>
            </div>
        </div>     
   
        
    <div class="space-50"></div>

    <!--/footer-->
 
</body>

</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>