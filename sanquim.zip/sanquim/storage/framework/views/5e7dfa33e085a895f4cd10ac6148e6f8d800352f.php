<?php $__env->startSection('conteudo'); ?>

<div class="row" >
  <div class="section section-signup " style="padding-top: 100px; width: 100%; background-position: center center; background-size: cover; margin: 0; border: 0;     display: flex;
      align-items: center; background-image: url('/img/capalogin.png');">
        <div class="container">
            <div class="row">
                <div class="col-md-8 ml-auto mr-auto col-xl-8">
                    <div class="card card-signup">
                            <form method="POST" action="<?php echo e(route('register')); ?>">
                                <div class="card-header card-header-primary text-center">
                                    <h4>Cadastro</h4>     
                                </div> 
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="input-group">
                                                <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="material-icons">face</i>
                                                </span>
                                                </div>

                                            
                                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus placeholder="Nome ">

                                                <?php if($errors->has('name')): ?>
                                                    <span class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                        
                                    </div>
                                    <div class="input-group">
                                                <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="material-icons">face</i>
                                                </span>
                                                </div>

                                            
                                                <input id="sobrenome" type="text" class="form-control<?php echo e($errors->has('sobrenome') ? ' is-invalid' : ''); ?>" name="sobrenome" value="<?php echo e(old('sobrenome')); ?>" required autofocus placeholder="Sobrenome">

                                                <?php if($errors->has('sobrenome')): ?>
                                                    <span class="invalid-feedback">
                                                        <strong><?php echo e($errors->first('sobrenome')); ?></strong>
                                                    </span>
                                                <?php endif; ?>
                                        
                                    </div>
                                    <div class="input-group">
                                            <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">email</i>
                                            </span>
                                            </div>
                                            <input id="email" type="email" placeholder="EX: sanquim@gmail.com" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                            <?php if($errors->has('email')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                    
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">lock_outline</i>
                                        </span>
                                        </div>
                                            <input id="password" type="password" placeholder="Senha"  class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                            <?php if($errors->has('password')): ?>
                                                <span class="invalid-feedback">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">lock_outline</i>
                                        </span>
                                        </div>
                                                <input id="password-confirm" placeholder="Confirmação Senha" type="password" class="form-control" name="password_confirmation" required>
                                            
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                        <span class="input-group-text">
                                            <i class="material-icons">call_end</i>
                                        </span>
                                        </div>
                                                    <input id="telefone" type="telefone" placeholder="EX: 999-9999" class="form-control <?php echo e($errors->has('telefone') ? ' is-invalid' : ''); ?>" name="telefone" value="<?php echo e(old('email')); ?>" placeholder="EX: 999-9999">
                    
                                                    <?php if($errors->has('telefone')): ?>
                                                        <span class="invalid-feedback">
                                                            <strong><?php echo e($errors->first('telefone')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                            
                                    </div>
                                <div class="form-check form-check-radio form-check-inline">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="radio" name="tipo" id="inlineRadio1" value="aluno"> Aluno
                                        <span class="circle">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                                <div class="form-check form-check-radio form-check-inline">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="radio" name="tipo" id="inlineRadio2" value="professor"> Professor
                                        <span class="circle">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                </div>
                                <div class="form-check form-check-radio form-check-inline">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="radio" name="tipo" id="inlineRadio3" value="administrador"> Administrador
                                        <span class="circle">
                                            <span class="check"></span>
                                        </span>
                                    </label>
                                    <ul>
                                        <select class="form-control" name="sala"><i class="fa fa-caret-down" aria-hidden="true"></i>

                                            <option value="SALA">SALA</option>
                                            <option value="Vestibulinho A">Vestibulinho A</option>
                                            <option value="Vestibulinho B">Vestibulinho B</option>
                                            <option value="Vestibular A">Vestibular A</option>
                                            <option value="Vestibular B">Vestibular B</option>
                                        </select>
                                        
                                    </ul>
                                </div>

                                <div class="card-footer justify-content-center">
                                    <div class="cd-section">
                                    </div>  
                                </div>

                                    <div class="card-footer justify-content-center">    
                                        <button class="btn btn-primary btn-sm" type="submit" >
                                            <?php echo e(__('Cadastrar')); ?>

                                        </button>
                                    </div>
                            
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
</div>
</Div>
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>