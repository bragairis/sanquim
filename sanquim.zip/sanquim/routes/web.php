<?php
//Alogado
route::get('/', 'SanquimController@home');
route::get('/professores', 'SanquimController@listaprof');
route::post('/mensagem', 'ContatoController@mensagem');
route::get('/defsanquim', 'SanquimController@defsanquim');
route::post('/mostrafooter', 'SanquimController@mostrafooter');
Route::get('/prevestibular', 'SanquimController@defpre_vestibular');
Route::get('/prevestibulinho', 'SanquimController@defpre_vestibulinho');
Route::get('/mostranoticia/{id}', 'NoticiaController@mostraNoticia');
Route::get('/revista', 'RevistaController@MostraRevista');
Route::get('/contato', 'ContatoController@carrossel_contato');

Route::get('/patrocinadores', function  () {
    return view('patrocinadores');
});
Route::get('/login', function  () {
    return view('login');
});
Route::get('/cadastro', function  () {
    return view('cadastro');
});
Route::get('/noticias', 'NoticiaController@listaNoticia');


//Logado
Route::group(['middleware' => 'LoginCheck'], function () {
Route::get('/areausuario', 'Area_usuarioController@nivel');
route::get('/alunosvestibular', 'Area_usuarioController@usersvestibular');
route::get('/alunosvestibulinho', 'Area_usuarioController@usersvestibulinho');
route::post('/update-perfil', 'Area_usuarioController@update_perfil');
route::get('/download-horario/{id}', 'Area_usuarioController@download_horario');
Route::get('/editarperfil', function  () {
    return view('editarperfil');
});
});

//Administrador
Route::group(['middleware' => 'admCheck'], function () {
Route::get('/configuracoes', 'ConfiguracoesController@edita');
Route::get('/msg-adm', 'ContatoController@mostramensagem');
Route::post('/alunos_carrossel', 'ConfiguracoesController@addalunos_carrossel');
Route::post('/footeredita/{id}', 'ConfiguracoesController@updatefooter');
Route::post('/simuladosedita/{id}', 'ConfiguracoesController@updatesimulados');
Route::post('/defhome_edita/{id}', 'ConfiguracoesController@updatedefhome');
Route::post('/defsanquim_edita/{id}', 'ConfiguracoesController@updatedefsanquim');
Route::post('/defpre_vestibular_edita/{id}', 'ConfiguracoesController@updatedefpre_vestibular');
Route::post('/defpre_vestibulinho_edita/{id}', 'ConfiguracoesController@updatedefpre_vestibulinho');
Route::post('/imgRevista/{id}', 'ConfiguracoesController@imgRevista');
Route::post('/imagem-carrossel/{id}', 'ConfiguracoesController@imagem_carrossel');
Route::post('/up-revista', 'ConfiguracoesController@UpRevista');
Route::post('/up-horarios', 'ConfiguracoesController@UpHorarios');
Route::post('/addProfessor', 'ConfiguracoesController@AddProfessores');
Route::post('/sobre-escritora/{id}', 'ConfiguracoesController@sobre_revista');
Route::post('/simulados-vestibular', 'ConfiguracoesController@AddSimulados_vestibular');
Route::post('/simulados-vestibulinho', 'ConfiguracoesController@AddSimulados_vestibulinho');
Route::post('/adicionarnoticia', 'NoticiaController@criarnoticia');
Route::get('/validac-vestibulinho', 'ConfiguracoesController@validacvestibulinho');
Route::delete('/validacao/deletarr/{id}', 'ConfiguracoesController@validacvestibulinhod');
Route::delete('/deletarsala/vestibulinho', 'ConfiguracoesController@deletarvestibulinho');
Route::get('/validac-vestibular', 'ConfiguracoesController@validacvestibular');
Route::delete('/validacao/deletar/{id}', 'ConfiguracoesController@validacvestibulard');
Route::delete('/deletarsala/vestibular', 'ConfiguracoesController@deletarvestibular');
Route::get('/validac-professor', 'ConfiguracoesController@validacprofessor');
Route::delete('/validacao/deletarrr/{id}', 'ConfiguracoesController@validacprofessord');
Route::delete('/deletar/professor', 'ProfessorController@deletarprofessor');
Route::delete('/professor/deletar/{id}', 'ProfessorController@deletar');
Route::delete('/noticia/deletar/{id}', 'NoticiaController@deletarNoticia');
Route::get('/criarnoticia', function  () {
    return view('criarnoticia');
});
});



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
