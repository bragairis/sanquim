
@extends('layout.principal')
@section('conteudo')

<div class="row" style="background-image: url('/img/capalogin.png');">
  <div class="section section-signup " style="padding-top: 100px; width: 100%; background-position: center center; background-size: cover; margin: 0; border: 0;     display: flex;
      align-items: center;">
      
              <link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen">           
              <div class="container card card-signup ">
                      <div class="card-header card-header-primary text-center">
                          <h4>Configurações</h4>                  
                          </a>                
                      </div>
                      <div class="row user-menu-container square"> 
                          <div class="col-md-3 user-menu-btns">
                                  <div class="btn-group-vertical square" id="responsive" style="margin-top: 0px;">
                                    <a href="#" class="btn btn-block btn-default active">
                                      Pagina Inicial
                                    <div class="ripple-container"></div></a>
                                    <a href="#" class="btn btn-default">
                                    Professores
                                    <div class="ripple-container"></div></a>
                                    <a href="#" class="btn btn-default">
                                    Usuários
                                    </a>
                                    <a href="#" class="btn btn-default">
                                    Definições
                                    </a>
                                    <a href="#" class="btn btn-default">
                                    Contato
                                    </a>
                                    <a href="#" class="btn btn-default">
                                    Revista
                                    </a>
                                    <a href="#" class="btn btn-default">
                                    Area do Aluno
                                    </a>
                                </div>
                          </div>
                          <div class="col-md-9 user-menu user-pad" style="padding-bottom: 20px;padding-top: 0px;">
                                <div class="user-menu-content active">
                                  <h2 > Administre a página inicial </h2>
                                    <table class = "table table-striped">
                                        <tbody>
                                          <tr>
                                            <td colspan="1">
                                              <h4 > Adicionar Ex-Alunos Destaque </h4>
                                                <form class="well" action="/alunos_carrossel" method="POST" enctype="multipart/form-data" >
                                                  {{ csrf_field() }} 
                                                    <fieldset>
                                                        <div class="container">
                                                          <div class="row">
                                                            <div class="form-group col-md-4">
                                                                <label class="control-label">Nome</label>
                                                                <div class="inputGroupContainer">
                                                                  <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="fullName" name="nome" class="form-control" required="true" value="" type="text"></div>
                                                              </div>
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label class="control-label">Universidade</label>
                                                                <div class="inputGroupContainer">
                                                                  <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine1" name="faculdade"  class="form-control" required="true" value="" type="text"></div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-4">
                                                                <label class="control-label">Mensagem</label>
                                                                <div class="inputGroupContainer">
                                                                  <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine2" name="mensagem"  class="form-control" required="true" value="" type="text"></div>
                                                                </div>
                                                            </div>
                                                            <label class="control-label">Foto</label>
                                                            <div class=" col-md-6 " style="padding: 0px;">
                                                              <br><input type="file" name="foto">
                                                            </div>
                                                            <div class="form-group col-md-5">
                                                              <div class="inputGroupContainer">
                                                                <button class="btn btn-info btn-round" style="float:right;" type="submit">
                                                                  Adicionar
                                                                </button>
                                                              </div>
                                                            </div>
                                                          </div>
                                                        </div>
                                                    </fieldset>
                                                </form>
                                            </td>
                                          </tr>
                                        </tbody>
                                    </table>
                                    <!-- aaaaa -->
                                    <div class="row" style="margin-left: 10px;">
                                        <form class="well" action="/imgRevista/{id}" method="POST" enctype="multipart/form-data" >
                                          {{ csrf_field() }} 
                                          <h4 > Alterar Imagem da Pagina da Revista </h4>
                                            <div class="col-md-4">
                                                  <input type="file" name="imagem">
                                            </div>
                                              <br>
                                              <div class="">
                                                <button class="btn btn-info btn-round" type="submit">
                                                    Adicionar
                                                </button>
                                              </div>
                                        </form>
                                        
                                        <form class="well" action="/imagem-carrossel/{id}" method="POST" enctype="multipart/form-data"  style="margin-left: 25px;">
                                        {{ csrf_field() }} 
                                          <h4 > Alterar Imagens do Carrosel (tamanho: 1366X768 ou 1280X720)</H4>
                                          <div class="col-md-4">
                                            <input type="file" name="foto1">
                                          </div>
                                          <div class="col-md-4">
                                            <input type="file" name="foto2">
                                          </div>
                                          <div class="col-md-4">
                                            <input type="file" name="foto3">
                                          </div>                                          
                                              <button class="btn btn-info btn-round">
                                                  Adicionar
                                              </button>
                                         
                                        </form>
                                    </div> 
                                </div> 

                                <div class="user-menu-content">
                                  <div class="container">
                                  <h2 > Adicionar Professor </h2>
                                    <table class="table table-striped">
                                        <tbody>
                                          <tr>
                                              <td colspan="1">
                                                
                                                <form class="well" action="/addProfessor" method="POST" enctype="multipart/form-data"> {{ csrf_field() }} 
                                                    <fieldset>
                                                      <div class="container">
                                                        <div class="row">
                                                          <div class="form-group col-md-4">
                                                              <label class="control-label">Nome Completo</label>
                                                              <div class="inputGroupContainer">
                                                                <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span><input id="fullName" name="nome" class="form-control" required="true" value="" type="text"></div>
                                                              </div>
                                                          </div>
                                                          <div class="form-group col-md-4">
                                                              <label class="control-label">Disciplina</label>
                                                              <div class="inputGroupContainer">
                                                                <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine1" name="disciplina"  class="form-control" required="true" value="" type="text"></div>
                                                              </div>
                                                          </div>
                                                        
                                                          <div class="form-group col-md-4">
                                                              <label class="control-label">Descrição</label>
                                                              <div class="inputGroupContainer">
                                                                <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine2" name="descricao"  class="form-control" required="true" value="" type="text"></div>
                                                              </div>
                                                          </div>
                                                          <div class="form-group col-md-4 ">
                                                              <label class="control-label">Email</label>
                                                              <div class="inputGroupContainer">
                                                                <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="city" name="email"  class="form-control" required="true" value="" type="text"></div>
                                                              </div>
                                                          </div>
                                                          <div class="col-md-4 ">
                                                              <label class="control-label">Foto</label>
                                                            <br>
                                                          <input type="file" name="foto">
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                    </fieldset>
                                                    <div class="card-footer justify-content-center">
                                                      <button class="btn btn-info btn-round"  type="submit">
                                                          Adicionar
                                                      </button>
                                                    </div>
                                                </form>
                                              </td>
                                          </tr>

                                        </tbody>
                                    </table>
                                  </div>
                                </div>

                                <div class="scroll user-menu-content">
                                    
                                    
                                      <div class="container">
                                      <h2 > Banco de Dados dos Usuários </h2>
                                      <h4> Delete ou Verifique a conta dos Usuários!</h4>
                                      <a href="/validac-professor"  class="btn btn-primary btn-round">
                                              Professores
                                          </a>
                                          <a href="validac-vestibular" class="btn btn-primary btn-round">
                                              Pré-Vestibular
                                          </a>
                                          <a href="validac-vestibulinho" class="btn btn-primary btn-round">
                                              Pré-Vestibulinho
                                          </a>
                                      </div>
                                </div>

                                <div class="user-menu-content">
                                    <h2 > Definições </h2>
                                    <h4> Adicione ou delete as definições do site!</h4>
                                  <div class="container">
                                        <div class="row">
                                          <div class="form-group col-md-6">
                                            <form action="/defhome_edita/{id}" method="POST" class="contact-form" >
                                              {{ csrf_field() }} 
                                              <label class="control-label"> Def. Sanquim (Pagina Principal)</label>
                                              <textarea name="definicao" class="form-control" rows="5" id="comment">{{$defhome->definicao}}</textarea>
                                              <div>
                                              <button class="btn btn-info btn-round" type="submit">
                                                      Adicionar
                                              </button>
                                              </div> 
                                            </form>
                                          </div>
                                          <div class="form-group col-md-6">
                                            <form action="/defsanquim_edita/{id}" method="POST" class="contact-form">
                                            {{ csrf_field() }} 
                                              <label class="control-label">Def. Sanquim</label>
                                              <textarea name="definicao" class="form-control" rows="5" id="comment">{{$defsanquim->definicao}}</textarea>
                                              <div>
                                              <button class="btn btn-info btn-round" type="submit">
                                                      Adicionar
                                              </button>
                                              </div> 
                                            </form>
                                          </div>  
                                        </div>

                                        <div class="row">
                                          <div class="form-group col-md-6">  
                                            <form action="/defpre_vestibular_edita/{id}" method="POST" class="contact-form">{{ csrf_field() }} 
                                                <label class="control-label"> Def. Curso Pré-Vestibular</label>
                                                <textarea name="definicao" class="form-control" rows="5" id="comment">{{$defpre_vestibular->definicao}}</textarea>
                                                <div>
                                                <button class="btn btn-info btn-round" type="submit">
                                                        Adicionar
                                                </button>
                                                </div>
                                            </form>
                                          </div>
                                          <div class="form-group col-md-6">
                                              <form action="/defpre_vestibulinho_edita/{id}" method="POST" class="contact-form">{{ csrf_field() }}                                
                                                  <label class="control-label"> Def. Curso Pré-Vestibuliho</label>
                                                  <textarea name="definicao" class="form-control" rows="5" id="comment">{{$defpre_vestibulinho->definicao}}</textarea>
                                                <div>
                                                  <button class="btn btn-info btn-round" type="submit">
                                                          Adicionar
                                                  </button>
                                                </div> 
                                              </form>
                                          </div>
                                        </div>                                   
                                  </div>
                                </div>

                              <div class="user-menu-content">
                                <h2 > Contato </h2>
                                  <div class="container">
                                    <form action="/footeredita/{id}" method="POST" class="contact-form">
                                      {{ csrf_field() }}
                                            <div class="row">
                                              <div class="form-group col-md-6">
                                                <label class="control-label">Localização</label>
                                                <textarea name="localizacao" class="form-control"  rows="2" id="comment" >{{$footer->localizacao}}</textarea> 
                                              </div> 
                                              <div class="form-group col-md-6">
                                                <label class="control-label">Horário de Funcionamento</label>
                                                <textarea name="horario" class="form-control" rows="1" id="comment">{{$footer->horario}}</textarea>
                                              </div>
                                              <div class="form-group col-md-6">
                                                <label class="control-label">Telefone</label>
                                                <textarea name="telefone" class="form-control" rows="1" id="comment">{{$footer->telefone}}</textarea>
                                              </div>
                                              <div class="form-group col-md-6">
                                                <label class="control-label">Link(Facebook)</label>
                                                <textarea name="facebook" class="form-control" rows="1" id="comment">{{$footer->facebook}}</textarea>
                                              </div>
                                              <div class="form-group col-md-6">
                                                <label class="control-label">Link(Instagram)</label>
                                                <textarea name="instagram" class="form-control" rows="1" id="comment">{{$footer->instagram}}</textarea>
                                              </div>
                                              <div class="form-group col-md-4">
                                                              <div class="inputGroupContainer">
                                                                <button class="btn btn-info btn-round" style="float:right;" type="submit">
                                                                  Adicionar
                                                                </button>
                                                              </div>
                                                            </div>
                                            </div>
                                    </form>
                                  </div>
                              </div>
                                    
                              <div class="user-menu-content">
                                <h2> Alterar Pagina da Revista </h2>
                                    <form class="well" action="/up-revista" method="POST" enctype="multipart/form-data">{{ csrf_field() }}
                                            <div class="col-md-4 ">
                                            <h4> Enviar Revista </h4>
                                                          <input type="file" name="arquivo">
                                                            </div>
                                            <div>
                                              <button class="btn btn-info btn-round" type="submit">
                                                      Adicionar
                                              </button>
                                            </div>
                                    </form>
                                  
                              </div>

                              <div class="user-menu-content">
                                <h2> Area do Aluno</h2>
                                <div class="row">
                                      <div class=" col-md-6">
                                        <form action="/simulados-vestibular" method="POST">@csrf
                                        <h4>Simulados Pré Vestibular </h4>                         
                                          <div class="inputGroupContainer">
                                          <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine2" name="dia"  class="form-control" required="true" value="" type="text"></div>
                                          </div>
                                            <button class="btn btn-info btn-round">
                                            Adicionar
                                            </button>
                                          </div>
                                        </form>
                                        <form class="well " action="/up-horarios" method="POST" enctype="multipart/form-data"> {{ csrf_field() }}
                                        <h4>Horarios (pdf)</h4>
                                                    <div class="col-md-4">
                                                      <input type="file" name="arquivo">
                                                    </div>
                                                    <br>
                                                    <button class="btn btn-info btn-round" type="submit">
                                                          Adicionar
                                                      </button>
                                      </form>
                                      </div>
                                      <div class=" col-md-6">          
                                        <form action="/simulados-vestibulinho" method="POST">@csrf
                                        <h4>Simulados Pré Vestibulinho </h4>                         
                                          <div class="inputGroupContainer">
                                          <div class="input-group"><span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span><input id="addressLine2" name="dia"  class="form-control" required="true" value="" type="text"></div>
                                          </div>
                                            <button class="btn btn-info btn-round">
                                            Adicionar
                                            </button>
                                          </div>
                                        </form>
                                      
                                      </div>  

                                      
                                </div>
                              </div>
                          </div>
                      </div>
                      <div class="space-50"></div>
              </div>
                      
              
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
          Material de apoio: Pré-Vestibulinho
        </button>
      </div>
    </div>
  </div> 
</div>

<div class="modal fade" id="downloads" tabindex="-1" role="dialog" aria-labelledby="downloadsLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="downloadsLabel">Material de Apoio</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <button class="btn btn-primary btn-round" href="https://drive.google.com/open?id=1ZpCIucvuYcj7ZwBPNNRX6fcdJdmbJiUx">
        Material de apoio: Pré-Vestibular 
       </button>
      </div>
    </div>
  </div>
</div> 

<script>
			$(function () { // wait for document ready
				// init controller
				var controller1 = new ScrollMagic.Controller({container: "#container1"});

			});
		</script>

    </body>

</html>
@stop

