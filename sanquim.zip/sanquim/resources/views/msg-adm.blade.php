  
@extends('layout.principal')
@section('conteudo')

 
<div class="row">
    <div class="section section-signup page-header" style="background-image: url('/img/ws_Mountain_View_1280x720.jpg');">
        <link href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css" rel="stylesheet" media="screen"> 
    
    <div class="container col-md-6" style="color:#000;">
        <div class="row user-menu-container square">
            <div class="col-md-3">
             <h3 style="color:#000;">Caixa de Mensagem</h3>
             <h4> Visualize todas as mensagens deixadas na aba de contato do site! </h4>
            </div>
            <div class="co-md-6">
             <ul class="user-menu-list" style="width:500px; height: 372px; overflow-y:scroll;">
              <div class="mail-box">   
             <div class="inbox-body">
              <table class="table table-inbox table-hover">  
                @foreach($msgpatrocinador as $p)                
                        <tr class="unread"  data-toggle="modal" data-target="#{{$p->id}}" >
                            <td class="view-message">{{$p->nome}}</td>
                            <td class="view-message">{{$p->assunto}}</td>
                        </tr>  
    
                        <div class="modal fade" id="{{$p->id}}" tabindex="-1" role="dialog" aria-labelledby="{{$p->id}}Label" aria-hidden="true">                                                             
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="{{$p->id}}Label">Caixa de Mensagem</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <h4>{{$p->nome}}</h4>
                                            </div>
                                            <div class="col-md-4">
                                                <h4>{{$p->email}}</h4>
                                            </div>
                                            
                                                <p>{{$p->mensagem}}</p>
                                                <p>{{$p->created_at}}</p>       
                                            
                                        </div>   
                                    </div>
                                </div>
                            </div> 
                        </div>
                @endforeach
            </table>
            </div>
            </div>
                                
            </ul>
                            
            </div>
        </div>

    </div>
    </div> 
</div>

@stop
