<!DOCTYPE html>
<html lang="en">

@extends('layout.principal')
@section('conteudo')

<div class="row">
        <div class="page-header">   
           <img class="w-100" src="\storage\img\noticia\{{$noticia->imagem}}">
        </div>
    </div>
    
<div class="main main-raised" >
    
        <div class="card card-signup">
        <div class="card-header card-header-primary text-center">
                <h2>{{ $noticia->titulo }}</h2> 
        </div>
    
    <div class="section section-contacts">
            <div class="row" style="padding-bottom: 60px;">
                <div class="col-md-9 ml-auto mr-auto">
                    <h2 class="text-center">{{ $noticia->subtitulo }}</h2>
                    <h4 style="text-align:justify;">{{ $noticia->noticia}}</h4>
                    
                </div>
        
        </div>

</div>
 

    <div class="main main-raised">
       
    </div>
    </div>
    </div>
    <!-- 	            end nav tabs -->
   



       @stop
</body>

</html>