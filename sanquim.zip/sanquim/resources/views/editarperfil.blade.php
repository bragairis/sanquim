@extends('layout.principal')
@section('conteudo')

<div class="row" >
  <div class="section section-signup " style="padding-top: 100px; width: 100%; background-position: center center; background-size: cover; margin: 0; border: 0;     display: flex;
      align-items: center; background-image: url('/img/capalogin.png');">
        <div class="container">
            <div class="row">
                <div class="col-md-8 ml-auto mr-auto col-xl-8">
                    <div class="card card-signup">
                            <form method="post" action="/update-perfil" enctype="multipart/form-data">
                                <div class="card-header card-header-primary text-center">
                                    <h4>Editar Perfil</h4>     
                                </div> 
                                @csrf
                                <div class="card-body">
                                    <div class="input-group"><h4>Nome</h4>  
                                                <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="material-icons">face</i>
                                                </span>
                                                </div>
                                                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ Auth::user()->name }}" >
                                                
                                                @if ($errors->has('name'))
                                                    <span class="invalid-feedback">
                                                        <strong>{{ $errors->first('name') }}</strong>
                                                    </span>
                                                @endif
                                        
                                    </div>
                                    <div class="input-group"><h4>Sobrenome</h4>  
                                                <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                    <i class="material-icons">face</i>
                                                </span>
                                                </div>
                                                <input id="sobrenome" type="text" class="form-control{{ $errors->has('sobrenome') ? ' is-invalid' : '' }}" name="sobrenome" value="{{ Auth::user()->sobrenome }}" >
                                                @if ($errors->has('sobrenome'))
                                                    <span class="invalid-feedback">
                                                        <strong>{{ $errors->first('sobrenome') }}</strong>
                                                    </span>
                                                @endif
                                        
                                    </div>
                                    <div class="input-group"><h4>E-mail</h4>  
                                            <div class="input-group-prepend">
                                            <span class="input-group-text">
                                                <i class="material-icons">email</i>
                                            </span>
                                            </div>
                                            <input id="email" type="email" placeholder="EX: sanquim@gmail.com" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ Auth::user()->email }}" >

                                            @if ($errors->has('email'))
                                                <span class="invalid-feedback">
                                                    <strong>{{ $errors->first('email') }}</strong>
                                                </span>
                                            @endif
                                    
                                    </div>
                                    
                                    <div class="input-group"><h4>Telefone</h4>  
                                        <div class="input-group-prepend">
                                        <span class="input-group-text">
                                        <i class="material-icons">call_end</i>
                                        </span>
                                        </div>
                                                    <input id="telefone" type="telefone" placeholder="EX: 999-9999" class="form-control {{ $errors->has('telefone') ? ' is-invalid' : '' }}" name="telefone" value="{{ Auth::user()->telefone }}" placeholder="EX: 999-9999">
                    
                                                    @if ($errors->has('telefone'))
                                                        <span class="invalid-feedback">
                                                            <strong>{{ $errors->first('telefone') }}</strong>
                                                        </span>
                                                    @endif
                                            
                                    </div>
                                    
                                    <div class="input-group">
                                        <div class=""><h4>Foto</h4>
                                            <div class="container" style="padding-left: 90px;">
                                                <h4  style="color: #8b8b8b;" >Utilize uma foto que possamos te identificar!</h5>
                                                <input type="file" name="imagem">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer justify-content-center">    
                                        <button class="btn btn-primary btn-sm" type="submit" >
                                            {{ __('Editar') }}
                                        </button>
                                    </div>
                            
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
</div>
</Div>
      @stop
