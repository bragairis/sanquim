<!DOCTYPE html>
<html lang="en">

@extends('layout.principal')
@section('conteudo')

        <div class="row">
    <div class="page-header">
        <div class="card card-raised card-carousel" style="margin-top: 0px; margin-bottom: 0px;">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
               
                <div class="carousel-inner">
                    <!-- IMAGEM TEM Q TER TAMANHO DE 1366X768 OU 1280X720-->
                    @foreach($carrossel as $p)
                    <div class="carousel-item active">
                        <img class="w-100"  src="{{ url("storage/img/carrossel/$p->foto1")}}" alt="First slide">
                      
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="{{ url("storage/img/carrossel/$p->foto2")}}" alt="Second slide">
                       
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="{{ url("storage/img/carrossel/$p->foto3")}}" alt="Third slide">
                        
                    </div>
                    @endforeach
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <i class="material-icons">keyboard_arrow_left</i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <i class="material-icons">keyboard_arrow_right</i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>




    <div id="team" class="main main-raised ">
        
            <div class="card card-signup">
                <div class="card-header card-header-primary text-center">
                 <h3>Professores</h3> 
                 </div>
        <div class="ssection ">
            <!--apaga se der merda-->
            <section id="team" class=" banner-sec ">
                <div class="container">
                    
                    
                    
                        <div class="row">
                        @foreach($professores as $p)
                        
                            <div class="col-xs-12 col-sm-6 col-md-4">
                           
                                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                                    <div class="mainflip">
                                  
                                       <div class="frontside">
                                            <div class="scard">
                                                <div class="card-body text-center">
                                            
                                                  <p><img class=" img-fluid" 
                                                  src="{{ url("storage/img/professores/$p->foto")}}" alt="card image" style="min-width: 250px;max-width: 250px;max-height: 250px;min-height: 250px;"></p>
                                                 <h4 class="card-title">{{$p->nome}}</h4>
                                                 <p class="card-text">{{$p->disciplina}}</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="backside">
                                            <div class="scard">
                                                 <div class="card-body text-center mt-4">
                                                 <h4 class="card-title">{{$p->nome}}</h4>
                                                 <p class="card-text">{{$p->descricao}}</p>
                                                </div>
                                           </div>
                                        </div>
                                   </div>
                                </div>
                                
                            </div>
                            @endforeach 
                        </div>
                       
                   
                </div>
            </section>
        </div>
        </div>
           
    </div>
    <!--apaga se der merda-->

    <!-- 	nseioqéisso -->
    <div class="section section-white">

    </div>
    <!--footer-->

</body>

</html>
@stop