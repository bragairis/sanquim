
@extends('layout.principal')
@section('conteudo')

 <div class="row" >
  <div class="section section-signup " style="padding-top: 100px; width: 100%; background-position: center center; background-size: cover; margin: 0; border: 0;     display: flex;
      align-items: center; background-image: url('/img/capalogin.png');">
      <div class="container">
        <div class="row">
        <div class="col-md-4 ml-auto mr-auto">
            <div class="card card-signup">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <div class="card-header card-header-primary text-center">
                  <h4>{{ __('Entrar') }}</h4>                  
                    </a>                
                </div>                           
                <div class="card-body">
                        <div class="input-group">
                                <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="material-icons">face</i>
                            </span>
                            </div>
                                <input id="email" type="email" placeholder="Email..." class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            
                        </div>

                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="material-icons">lock_outline</i>
                            </span>
                            </div>
                                <input id="password" type="password" placeholder="Senha..." class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                          
                        </div>

                        <div class="card-footer justify-content-center row">
                            
                                <button type="submit" class="btn btn-primary btn-round">
                                    {{ __('Login') }}
                                </button>
                           
                            </div>
                        </div>
                        <div class="card-footer justify-content-center">
                    <div class="cd-section">
                        <div class="title">
                                <h4>
                                    <small>Possui conta?</small>   
                                <br>
                                    <small>Não? Então...</small>
                                    </h4>                            
                        </div>
                    </div>  
                </div>    
                    <div class="card-footer justify-content-center">    

                       <a href="/register" class="btn btn-primary btn-sm">Cadastre-se</a>               
                    </div>    
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
      <!-- footer -->
     
    </div>
     </div>
</body>

</html>
@endsection
