<!DOCTYPE html>
<html lang="en">

@extends('layout.principal')
@section('conteudo')

        <!--carrosel principal-->
        <<div class="row">
    <div class="page-header">
        <div class="card card-raised card-carousel" style="margin-top: 0px; margin-bottom: 0px;">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
                    <!-- IMAGEM TEM Q TER TAMANHO DE 1366X768 OU 1280X720-->
                    @foreach($carrossel as $p)
                    <div class="carousel-item active">
                        <img class="w-100"  src="{{ url("storage/img/carrossel/$p->foto1")}}" alt="First slide">
                      
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="{{ url("storage/img/carrossel/$p->foto2")}}" alt="Second slide">
                       
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="{{ url("storage/img/carrossel/$p->foto3")}}" alt="Third slide">
                        
                    </div>
                    @endforeach
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <i class="material-icons">keyboard_arrow_left</i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <i class="material-icons">keyboard_arrow_right</i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
        <!--/carrosel principal-->

        <div class="main main-raised ">
            <section class="banner-sec" style="padding:30px;">
                <div class="container">
                    <div class="row ">
                            @foreach($noticia as $p)
                        <div class=" col-md-4" style="    margin-top: 60px;">
                            <img class="card-img-top"  src="{{ url("storage/img/noticia/$p->imagem")}}" href="/mostranoticia/{{$p->id}}">
                            <div class="card-body">
                                <h4 class="card-title">{{$p->titulo}}</h4>          
                                <p class="card-text">{{$p->subtitulo}}</p>                                    
                                <div class="card-footer justify-content-center">    
                                <a href="/mostranoticia/{{$p->id}}" class="btn btn-primary btn-round">Abrir</a>               
                                </div>               
                            </div>
                        </div>
                        
                            @endforeach     
                    </div>
                </div>                           
            </section>
        
        </div>



        <div class="space-50"></div>

        <!-- footer -->
        @stop
</body>

</html>