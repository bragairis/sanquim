<!DOCTYPE html>
<html lang="en">

@extends('layout.principal')
@section('conteudo')

<!--carrosel principal-->
<div class="row">
    <div class="page-header">
        <div class="card card-raised card-carousel" style="margin-top: 0px; margin-bottom: 0px;">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
               
                <div class="carousel-inner">
                    <!-- IMAGEM TEM Q TER TAMANHO DE 1366X768 OU 1280X720-->
                    @foreach($carrossel as $p)
                    <div class="carousel-item active">
                        <img class="w-100"  src="{{ url("storage/img/carrossel/$p->foto1")}}" alt="First slide">
                      
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="{{ url("storage/img/carrossel/$p->foto2")}}" alt="Second slide">
                       
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="{{ url("storage/img/carrossel/$p->foto3")}}" alt="Third slide">
                        
                    </div>
                    @endforeach
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <i class="material-icons">keyboard_arrow_left</i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <i class="material-icons">keyboard_arrow_right</i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>
</div>
<!--/carrosel principal-->

<div class="main main-raised ">
    <div class="section">
        <section class="banner-sec">
            <div class="container">
                <div class="row">
                <div class="col-md-3">
                <?php $cont = 0 ?>
                @foreach($noticia as $p)
                   
                    @if($cont++ == 2)
                        </div>
                        <div class="col-md-3">
                    @endif

                        <div class="card "> <img class="img-fluid" style="    height: 150px;width: 290px;" src="{{ url("storage/img/noticia/$p->imagem")}}" alt="">
                            
                            <div class="card-body ">
                                <div class="news-title">
                                    <h3 class=" title-small"><a href="/mostranoticia/{{$p->id}}" target="_blank">{{$p->titulo}}</a></h3>
                                </div>
                            </div>
                        </div>
                        

                    @endforeach
                    </div>
                    
                    <div class="col-md-4 top-slider outrocard">
                        <div class="news-block">
                            <div class="news-media">
                            @foreach($imgRevista as $p)
                            <img src="{{ url("storage/img/imgRevista/$p->imagem")}}" alt="imagem revista" style="width: 150%; height:400px;"/>
                            @endforeach
                            </div>
                            <div class="col-md-12">
                            <div class="news-title">
                                <h2 class=" title-large" style="text-align:center;     width: 150%;">Conheça
                                        nossa revista   <a href="/revista" ><i class="fa fa-plus-circle" aria-hidden="true"></i></a></h2>
                            </div>
                                </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                    <a  href="/noticias" ><span  class="badge badge-pill badge-danger" style="width: 100%; background-color: #5c3d99;"><h6>Clique aqui para mais notícias</h6></span></a>
                    </div>
                </div>
            </div>
        </section>


        <!--ARRUMAR ISSO NO FUTURO === AS IMAGEM N TA RESPONSIVA-->
        <div class="cinza ROW">
            <div class="Scard col-md-6 mt-5 mb-5">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-interval="100000">
                    <div class="w-100 carousel-inner" role="listbox">
                    <?php $cont = 0 ?>
                    @foreach($alunoscarrossel as $p)
                    
                    @if($cont++ == 1)
                        <div id="activee" class="carousel-item active">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <img src="{{ url("storage/img/alunos-carrossel/$p->foto")}}" alt="" style="width: 150px; height:150px;" class="rounded-circle " />
                                    </div>
                                    <div class="col-sm-9">
                                        <h3>{{$p->nome}}, {{$p->faculdade}}</h3>
                                        <small>{{$p->mensagem}}</small>
                                        
                                    </div>
                                </div>
                            </div>
                            @else
                            <div id="activee" class="carousel-item">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <img src="{{ url("storage/img/alunos-carrossel/$p->foto")}}" alt="" style="width: 150px; height:150px;" class="rounded-circle" />
                                    </div>
                                    <div class="col-sm-9">
                                    <h3>{{$p->nome}}, {{$p->faculdade}}</h3>
                                        <small>{{$p->mensagem}}</small>
                                    </div>
                                </div>
                            </div>
                            @endif
                        @endforeach
            
               
                        </div>
                </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <i class="material-icons" style="padding-right: 250px;">keyboard_arrow_left</i>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <i class="material-icons" style="padding-left: 250px;">keyboard_arrow_right</i>
                        <span class="sr-only">Next</span>
                    </a>
                    
            </div>
        </div>



        <div class="container">
            <div class="row text-center">
                <div class="col-md-8 ml-auto mr-auto" action="sanquimController@defhome1">
                    @foreach($defhome as $p)
                    <h2>O que é o Sanquim?</h2>
                    <h4>{{$p->definicao}}
                    </h4>
                    <a href="/defsanquim" class="btn btn-primary btn-lg">Saiba mais</a>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>


<div class="space-50"></div>

<!--/footer-->

</body>

</html>
@stop